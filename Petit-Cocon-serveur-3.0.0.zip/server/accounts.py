"""Invite-only accounts for the encrypted Petit Cocon family store."""
import base64
import binascii
import hashlib
import json
import os
import re
import secrets
import threading
import time

TOKEN = re.compile(r"[A-Za-z0-9_-]{43}")
EMAIL = re.compile(r"[^@\s]+@[^@\s]+", re.ASCII)
SESSION_SECONDS = 30 * 86400
INVITE_SECONDS = 48 * 3600
MAX_MEMBERS = 12


class RequestError(Exception):
    def __init__(self, status, code):
        super().__init__(code)
        self.status = status
        self.code = code


def digest(value):
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def token():
    return secrets.token_urlsafe(32)


def bearer(headers):
    value = headers.get("Authorization", "")
    return value[7:] if value.startswith("Bearer ") else ""


def initialize(connection):
    connection.executescript("""
        CREATE TABLE IF NOT EXISTS server_info (
            name TEXT PRIMARY KEY, value TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS accounts (
            id TEXT PRIMARY KEY, family TEXT NOT NULL REFERENCES families(id),
            email TEXT UNIQUE NOT NULL, name TEXT NOT NULL,
            role TEXT NOT NULL CHECK(role IN ('owner','parent')),
            salt BLOB NOT NULL, credential BLOB NOT NULL, envelope TEXT NOT NULL
        );
        CREATE INDEX IF NOT EXISTS accounts_family ON accounts(family);
        CREATE UNIQUE INDEX IF NOT EXISTS family_owner ON accounts(family) WHERE role='owner';
        CREATE TABLE IF NOT EXISTS sessions (
            digest TEXT PRIMARY KEY, account TEXT NOT NULL REFERENCES accounts(id) ON DELETE CASCADE,
            expires INTEGER NOT NULL
        );
        CREATE INDEX IF NOT EXISTS sessions_account ON sessions(account);
        CREATE TABLE IF NOT EXISTS invitations (
            id TEXT PRIMARY KEY, digest TEXT UNIQUE NOT NULL,
            family TEXT NOT NULL REFERENCES families(id), expires INTEGER NOT NULL
        );
        CREATE INDEX IF NOT EXISTS invitations_family ON invitations(family);
    """)
    connection.execute(
        "INSERT OR IGNORE INTO server_info(name,value) VALUES('account_salt_v1',?)", (token(),)
    )
    if not any(row["name"] == "session_digest" for row in connection.execute("PRAGMA table_info(push)")):
        connection.execute("ALTER TABLE push ADD COLUMN session_digest TEXT")
    connection.execute("CREATE INDEX IF NOT EXISTS push_session ON push(session_digest)")


def account_for(connection, secret):
    if not TOKEN.fullmatch(secret):
        return None
    return connection.execute(
        "SELECT a.*,s.digest AS session_digest,s.expires FROM sessions s "
        "JOIN accounts a ON a.id=s.account WHERE s.digest=? AND s.expires>?",
        (digest(secret), int(time.time())),
    ).fetchone()


def profile(row):
    return {name: row[name] for name in ("id", "email", "name", "role")}


def email_address(value):
    if not isinstance(value, str):
        raise ValueError()
    email = value.strip().lower()
    if len(email) > 254 or not email.isascii() or not email.isprintable() or not EMAIL.fullmatch(email):
        raise ValueError()
    return email


def proof_value(value):
    if not isinstance(value, str) or not TOKEN.fullmatch(value):
        raise ValueError()
    return value


def encrypted_envelope(value):
    if not isinstance(value, dict):
        raise ValueError()
    try:
        iv, ciphertext = value["iv"], value["ciphertext"]
        if len(iv) != 16 or len(ciphertext) != 64:
            raise ValueError()
        if len(base64.b64decode(iv, validate=True)) != 12 or len(base64.b64decode(ciphertext, validate=True)) != 48:
            raise ValueError()
    except binascii.Error as error:
        raise ValueError() from error
    return json.dumps({"iv": iv, "ciphertext": ciphertext}, separators=(",", ":"))


def derive_credential(proof, salt):
    return hashlib.scrypt(proof.encode("ascii"), salt=salt, n=2**15, r=8, p=3, maxmem=64*1024*1024, dklen=32)


class AuthThrottle:
    """Bound both concurrent scrypt work and login attempts on a family server."""

    def __init__(self):
        self.lock = threading.Lock()
        self.workers = threading.BoundedSemaphore(2)
        self.attempts = {}
        self.last_cleanup = 0

    def reserve(self, key):
        now = time.monotonic()
        with self.lock:
            if now - self.last_cleanup > 60:
                self.attempts = {k: v for k, v in self.attempts.items() if v[0] > now}
                self.last_cleanup = now
            for bucket, length, maximum in (("all", 60, 120), (key, 600, 12)):
                expiry, used = self.attempts.get(bucket, (0, 0))
                if expiry <= now:
                    expiry, used = now + length, 0
                if used >= maximum:
                    raise RequestError(429, "too_many_attempts")
                self.attempts[bucket] = expiry, used + 1

    def credential(self, proof, salt):
        if not self.workers.acquire(blocking=False):
            raise RequestError(429, "try_again")
        try:
            return derive_credential(proof, salt)
        finally:
            self.workers.release()


class Accounts:
    def __init__(self, connect, mutex, validate_box):
        self.connect = connect
        self.mutex = mutex
        self.validate_box = validate_box
        self.throttle = AuthThrottle()

    def session(self, connection, account):
        now = int(time.time())
        connection.execute(
            "DELETE FROM push WHERE session_digest IN (SELECT digest FROM sessions WHERE expires<=?)", (now,)
        )
        connection.execute("DELETE FROM sessions WHERE expires<=?", (now,))
        secret = token()
        expires = now + SESSION_SECONDS
        connection.execute("INSERT INTO sessions VALUES(?,?,?)", (digest(secret), account["id"], expires))
        return {
            "account": profile(account),
            "family": account["family"],
            "token": secret,
            "expiresAt": expires,
            "envelope": json.loads(account["envelope"]),
        }

    def login(self, body):
        email, proof = email_address(body["email"]), proof_value(body["proof"])
        self.throttle.reserve(email)
        with self.connect() as connection:
            row = connection.execute("SELECT * FROM accounts WHERE email=?", (email,)).fetchone()
        actual = self.throttle.credential(proof, row["salt"] if row else b"Petit Cocon auth")
        expected = row["credential"] if row else bytes(32)
        if not secrets.compare_digest(actual, expected) or row is None:
            raise RequestError(401, "invalid_credentials")
        with self.mutex, self.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            current = connection.execute("SELECT * FROM accounts WHERE id=?", (row["id"],)).fetchone()
            if current is None or not secrets.compare_digest(actual, current["credential"]):
                raise RequestError(401, "invalid_credentials")
            return self.session(connection, current)

    def invitation(self, connection, secret):
        if not TOKEN.fullmatch(secret):
            raise RequestError(410, "invalid_invitation")
        row = connection.execute(
            "SELECT * FROM invitations WHERE digest=? AND expires>?", (digest(secret), int(time.time()))
        ).fetchone()
        if row is None:
            raise RequestError(410, "invalid_invitation")
        return row

    def check_invitation(self, body):
        with self.connect() as connection:
            invite = self.invitation(connection, proof_value(body["invite"]))
            row = connection.execute("SELECT box FROM families WHERE id=?", (invite["family"],)).fetchone()
        return {"family": invite["family"], "box": json.loads(row["box"])}

    def register(self, body):
        name = body["name"]
        if not isinstance(name, str) or not name.strip() or len(name.strip()) > 80:
            raise ValueError()
        email, proof = email_address(body["email"]), proof_value(body["proof"])
        envelope = encrypted_envelope(body["envelope"])
        mode = body["mode"]
        if mode not in ("create", "claim", "invite"):
            raise ValueError()
        self.throttle.reserve(email)
        box = None
        if mode in ("create", "claim"):
            expected = os.environ.get("COCON_CREATE_KEY", "")
            setup = body.get("setupKey", "")
            if not expected or not isinstance(setup, str) or not secrets.compare_digest(setup.encode(), expected.encode()):
                raise RequestError(403, "creation_key_required")
            if mode == "create":
                box = self.validate_box(body["box"])
        with self.connect() as connection:
            if mode == "invite":
                self.invitation(connection, proof_value(body["invite"]))
            if connection.execute("SELECT 1 FROM accounts WHERE email=?", (email,)).fetchone():
                raise RequestError(409, "email_in_use")
        salt = secrets.token_bytes(16)
        credential = self.throttle.credential(proof, salt)
        with self.mutex, self.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            if connection.execute("SELECT 1 FROM accounts WHERE email=?", (email,)).fetchone():
                raise RequestError(409, "email_in_use")
            role = "owner"
            if mode == "invite":
                invitation = self.invitation(connection, body["invite"])
                family = invitation["family"]
                if connection.execute("SELECT COUNT(*) FROM accounts WHERE family=?", (family,)).fetchone()[0] >= MAX_MEMBERS:
                    raise RequestError(409, "member_limit")
                connection.execute("DELETE FROM invitations WHERE id=?", (invitation["id"],))
                role = "parent"
            elif mode == "claim":
                family = body["family"]
                legacy = proof_value(body["legacyToken"])
                row = connection.execute("SELECT token_hash FROM families WHERE id=?", (family,)).fetchone()
                if row is None or not row["token_hash"] or not secrets.compare_digest(row["token_hash"], digest(legacy)):
                    raise RequestError(403, "legacy_access_required")
                # Retire the shared bearer and its push subscriptions in the same transaction.
                connection.execute("UPDATE families SET token_hash='' WHERE id=?", (family,))
                connection.execute("DELETE FROM push WHERE family=?", (family,))
            else:
                if connection.execute("SELECT COUNT(*) FROM families").fetchone()[0] >= int(os.environ.get("COCON_MAX_FAMILIES", "20")):
                    raise RequestError(409, "family_limit")
                family = secrets.token_urlsafe(24)
                connection.execute("INSERT INTO families VALUES(?,?,?,?,?)", (family, "", 1, box, time.time()))
            account_id = token()
            connection.execute(
                "INSERT INTO accounts VALUES(?,?,?,?,?,?,?,?)",
                (account_id, family, email, name.strip(), role, salt, credential, envelope),
            )
            account = connection.execute("SELECT * FROM accounts WHERE id=?", (account_id,)).fetchone()
            return self.session(connection, account)

    def change_password(self, secret, body):
        old = proof_value(body["currentProof"])
        new = proof_value(body["proof"])
        if secrets.compare_digest(old, new):
            raise RequestError(400, "password_unchanged")
        envelope = encrypted_envelope(body["envelope"])
        with self.connect() as connection:
            current = account_for(connection, secret)
        if current is None:
            raise RequestError(401, "unauthorized")
        self.throttle.reserve(current["email"])
        actual = self.throttle.credential(old, current["salt"])
        if not secrets.compare_digest(actual, current["credential"]):
            raise RequestError(403, "invalid_credentials")
        salt = secrets.token_bytes(16)
        credential = self.throttle.credential(new, salt)
        with self.mutex, self.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = account_for(connection, secret)
            if row is None or not secrets.compare_digest(current["credential"], row["credential"]):
                raise RequestError(401, "unauthorized")
            account, keep = row["id"], row["session_digest"]
            connection.execute("UPDATE accounts SET salt=?,credential=?,envelope=? WHERE id=?", (salt, credential, envelope, account))
            connection.execute(
                "DELETE FROM push WHERE session_digest IN (SELECT digest FROM sessions WHERE account=? AND digest<>?)",
                (account, keep),
            )
            connection.execute("DELETE FROM sessions WHERE account=? AND digest<>?", (account, keep))
        return {"ok": True}

    def handle(self, handler, path):
        method = handler.command
        part = path.split("/")[3:]
        if part == ["parameters"] and method == "GET":
            with self.connect() as connection:
                salt = connection.execute("SELECT value FROM server_info WHERE name='account_salt_v1'").fetchone()[0]
            return handler.send(200, {"version": 1, "salt": salt})
        if method == "POST" and part in (["register"], ["login"], ["invitations", "check"]):
            limit = handler.max_state + 4096 if part == ["register"] else 8192
            body = json.loads(handler.body(limit))
            if part == ["register"]:
                return handler.send(201, self.register(body))
            if part == ["login"]:
                return handler.send(200, self.login(body))
            return handler.send(200, self.check_invitation(body))
        secret = bearer(handler.headers)
        if part == ["password"] and method == "POST":
            return handler.send(200, self.change_password(secret, json.loads(handler.body(8192))))
        with self.mutex, self.connect() as connection:
            connection.execute("BEGIN IMMEDIATE")
            row = account_for(connection, secret)
            if row is None:
                raise RequestError(401, "unauthorized")
            family = row["family"]
            now = int(time.time())
            status = 200
            if part == ["logout"] and method == "POST":
                connection.execute("DELETE FROM push WHERE session_digest=?", (row["session_digest"],))
                connection.execute("DELETE FROM sessions WHERE digest=?", (row["session_digest"],))
                result = {"ok": True}
            elif part == ["members"] and method == "GET":
                result = {"members": [
                    profile(member) for member in connection.execute(
                        "SELECT * FROM accounts WHERE family=? ORDER BY role,email", (family,)
                    )
                ]}
                if row["role"] == "owner":
                    result["invitations"] = [
                        dict(invite) for invite in connection.execute(
                            "SELECT id,expires FROM invitations WHERE family=? AND expires>? ORDER BY expires",
                            (family, now),
                        )
                    ]
            elif part == ["invitations"] and method == "POST":
                self.require_owner(row)
                connection.execute("DELETE FROM invitations WHERE expires<=?", (now,))
                queued = connection.execute("SELECT COUNT(*) FROM invitations WHERE family=?", (family,)).fetchone()[0]
                members = connection.execute("SELECT COUNT(*) FROM accounts WHERE family=?", (family,)).fetchone()[0]
                if queued >= MAX_MEMBERS or members >= MAX_MEMBERS:
                    raise RequestError(409, "member_limit")
                invitation_id, code, expires = token(), token(), now + INVITE_SECONDS
                connection.execute("INSERT INTO invitations VALUES(?,?,?,?)", (invitation_id, digest(code), family, expires))
                status, result = 201, {"id": invitation_id, "invite": code, "expires": expires}
            elif len(part) == 2 and part[0] in ("invitations", "members") and method == "DELETE":
                self.require_owner(row)
                if not TOKEN.fullmatch(part[1]):
                    raise RequestError(404, "not_found")
                if part[0] == "invitations":
                    cursor = connection.execute("DELETE FROM invitations WHERE family=? AND id=?", (family, part[1]))
                else:
                    connection.execute(
                        "DELETE FROM push WHERE session_digest IN (SELECT s.digest FROM sessions s "
                        "JOIN accounts a ON a.id=s.account WHERE a.family=? AND a.id=? AND a.role='parent')",
                        (family, part[1]),
                    )
                    cursor = connection.execute(
                        "DELETE FROM accounts WHERE family=? AND id=? AND role='parent'", (family, part[1])
                    )
                if cursor.rowcount != 1:
                    raise RequestError(404, "not_found")
                result = {"ok": True}
            else:
                raise RequestError(404, "not_found")
        return handler.send(status, result)

    @staticmethod
    def require_owner(row):
        if row["role"] != "owner":
            raise RequestError(403, "owner_required")
