"""Petit Cocon private sync: opaque encrypted vaults, CAS revisions and Web Push.
No health data, encryption keys or family tokens are written to logs.
"""
import base64, hashlib, json, os, re, secrets, sqlite3, threading, time, mimetypes
from pathlib import Path
from http.server import ThreadingHTTPServer, BaseHTTPRequestHandler
from urllib.parse import urlparse, unquote
from datetime import datetime, timedelta
from zoneinfo import ZoneInfo
if __package__:
 from . import accounts
else:
 import accounts

ROOT=Path(__file__).resolve().parent
DATA=Path(os.environ.get('COCON_DATA',ROOT/'data')); DATA.mkdir(parents=True,exist_ok=True)
PUBLIC=Path(os.environ.get('COCON_PUBLIC',ROOT.parent/'app/src/main/assets')).resolve()
DB=DATA/'cocon.sqlite3'; MUTEX=threading.RLock(); ID=re.compile(r'^[a-zA-Z0-9_-]{12,100}$')
MAX_STATE=18*1024*1024; MAX_BLOB=30*1024*1024
def connect():
 c=sqlite3.connect(DB,timeout=20);c.row_factory=sqlite3.Row
 c.execute('PRAGMA foreign_keys=ON')
 return c
def init_db():
 with connect() as c:
  c.executescript('''PRAGMA journal_mode=WAL;
  CREATE TABLE IF NOT EXISTS families(id TEXT PRIMARY KEY,token_hash TEXT NOT NULL,revision INTEGER NOT NULL DEFAULT 0,box TEXT NOT NULL,updated REAL NOT NULL);
  CREATE TABLE IF NOT EXISTS snapshots(family TEXT,revision INTEGER,box TEXT,created REAL,PRIMARY KEY(family,revision));
  CREATE TABLE IF NOT EXISTS blobs(family TEXT,id TEXT,path TEXT,size INTEGER,PRIMARY KEY(family,id));
  CREATE TABLE IF NOT EXISTS push(family TEXT,device TEXT,subscription TEXT,schedule TEXT,last TEXT DEFAULT '{}',PRIMARY KEY(family,device));
  ''')
  accounts.initialize(c)
def digest(v):return hashlib.sha256(v.encode()).hexdigest()
def validate_box(v):
 if not isinstance(v,dict) or not isinstance(v.get('iv'),str) or not isinstance(v.get('ciphertext'),str):raise ValueError('encrypted_box_required')
 if len(v['iv'])>64 or len(v['ciphertext'])>MAX_STATE:raise ValueError('invalid_box')
 return json.dumps({'iv':v['iv'],'ciphertext':v['ciphertext']},separators=(',',':'))
ACCOUNTS=accounts.Accounts(connect,MUTEX,validate_box)
def vapid_keys():
 try:
  from cryptography.hazmat.primitives.asymmetric import ec
  from cryptography.hazmat.primitives import serialization
  p=DATA/'vapid-private.pem'
  with MUTEX:
   if not p.exists():
    key=ec.generate_private_key(ec.SECP256R1());p.write_bytes(key.private_bytes(serialization.Encoding.PEM,serialization.PrivateFormat.PKCS8,serialization.NoEncryption()));p.chmod(0o600)
   key=serialization.load_pem_private_key(p.read_bytes(),None)
  public=key.public_key().public_bytes(serialization.Encoding.X962,serialization.PublicFormat.UncompressedPoint)
  return str(p),base64.urlsafe_b64encode(public).decode().rstrip('=')
 except ImportError:return None,None
def valid_subscription(s):
 u=urlparse(s.get('endpoint',''));host=(u.hostname or '').lower()
 allowed=host=='fcm.googleapis.com' or host=='web.push.apple.com' or host.endswith('.push.apple.com') or host.endswith('.push.services.mozilla.com') or host=='updates.push.services.mozilla.com' or host.endswith('.notify.windows.com')
 return u.scheme=='https' and u.port in (None,443) and not u.username and not u.password and allowed and isinstance(s.get('keys'),dict) and len(json.dumps(s))<12000
def _next_due(r,now,last=0,zone='Europe/Paris'):
 base=float(r['at'])/1000;repeat=r.get('repeat','once')
 if base>now and base>last and repeat!='weekly':return base
 if repeat=='once':return base if last<base and now-base<21600 else None
 if repeat=='interval':
  step=max(1,int(r.get('intervalMinutes',180)))*60;latest=base+max(0,int((now-base)//step))*step
  if latest>last and now-latest<120:return latest
  return base+(int((max(now,last)-base)//step)+1)*step
 try:tz=ZoneInfo(zone)
 except Exception:tz=ZoneInfo('UTC')
 d=datetime.fromtimestamp(max(now,last,base),tz);origin=datetime.fromtimestamp(base,tz)
 hour=int(r.get('hour',origin.hour));minute=int(r.get('minute',origin.minute))
 for i in range(370):
  cur=(d+timedelta(days=i)).replace(hour=hour,minute=minute,second=0,microsecond=0)
  if repeat=='weekly' and (cur.weekday()+1)%7 not in (r.get('weekdays') or [(origin.weekday()+1)%7]):continue
  if repeat=='monthly':
   import calendar
   if cur.day!=min(int(r.get('monthDay',origin.day)),calendar.monthrange(cur.year,cur.month)[1]):continue
  at=cur.timestamp()
  if at<base or at<=last:continue
  if at>now or now-at<120:return at
 return None

def next_due(r,now,last=0,zone='Europe/Paris'):
 value=_next_due(r,now,last,zone)
 return None if value is not None and r.get('untilAt') and value>r['untilAt']/1000 else value

def is_quiet(schedule,now):
 try:
  a=schedule.get('quietStart','');b=schedule.get('quietEnd','')
  if not a or not b or a==b:return False
  tz=ZoneInfo(schedule.get('zone','Europe/Paris'));d=datetime.fromtimestamp(now,tz);cur=d.hour*60+d.minute
  start=int(a[:2])*60+int(a[3:]);end=int(b[:2])*60+int(b[3:])
  return start<=cur<end if start<end else cur>=start or cur<end
 except Exception:return False

class Handler(BaseHTTPRequestHandler):
 server_version='PetitCocon/3'
 max_state=MAX_STATE
 timeout=45
 def log_message(self,*args):pass
 def send(self,status,data=None,content_type='application/json'):
  if data is None:data={}
  body=json.dumps(data,separators=(',',':')).encode() if isinstance(data,(dict,list)) else data
  self.send_response(status);self.send_header('Content-Type',content_type);self.send_header('Content-Length',str(len(body)))
  self.send_header('Cache-Control','no-store' if self.path.startswith('/api/') else 'no-cache')
  self.send_header('X-Content-Type-Options','nosniff');self.send_header('Referrer-Policy','no-referrer')
  self.send_header('X-Frame-Options','DENY')
  # Native local WebView has this fixed origin. Other web clients use same origin.
  origin=self.headers.get('Origin','')
  if origin=='https://cocon.local':self.send_header('Access-Control-Allow-Origin',origin);self.send_header('Vary','Origin')
  self.send_header('Access-Control-Allow-Headers','Authorization,Content-Type');self.send_header('Access-Control-Allow-Methods','GET,POST,PUT,DELETE,OPTIONS')
  self.end_headers()
  if self.command!='HEAD':self.wfile.write(body)
 def body(self,limit=MAX_STATE):
  n=int(self.headers.get('Content-Length','0'))
  if n<=0 or n>limit:raise ValueError('invalid_body_size')
  body=self.rfile.read(n)
  if len(body)!=n:raise ValueError('incomplete_body')
  return body
 def auth(self,connection,family):
  token=accounts.bearer(self.headers)
  if not ID.fullmatch(family) or not ID.fullmatch(token):raise accounts.RequestError(401,'unauthorized')
  session=accounts.account_for(connection,token)
  if session is not None and session['family']==family:return session['session_digest']
  row=connection.execute('SELECT token_hash FROM families WHERE id=?',(family,)).fetchone()
  if row and row['token_hash'] and secrets.compare_digest(row['token_hash'],digest(token)):return None
  raise accounts.RequestError(401,'unauthorized')
 def do_OPTIONS(self):self.send(204,b'','text/plain')
 def do_HEAD(self):self.do_GET()
 def do_GET(self):self.route()
 def do_POST(self):self.route()
 def do_PUT(self):self.route()
 def do_DELETE(self):self.route()
 def route(self):
  try:self.handle_route()
  except accounts.RequestError as error:self.send(error.status,{'error':error.code})
  except (ValueError,KeyError,TypeError,json.JSONDecodeError):self.send(400,{'error':'invalid_request'})
  except (BrokenPipeError,ConnectionResetError,TimeoutError):pass
  except Exception:self.send(500,{'error':'server_error'})
 def handle_route(self):
  path=urlparse(self.path).path
  if path=='/api/health':return self.send(200,{'ok':True,'version':3,'accounts':True,'push':bool(vapid_keys()[1])})
  if path.startswith('/api/accounts/'):return ACCOUNTS.handle(self,path)
  if path=='/api/push-key' and self.command=='GET':return self.send(200,{'key':vapid_keys()[1]})
  if path=='/api/families' and self.command=='POST':
   # A private family vault is created only with a long random client capability.
   body=json.loads(self.body());token=body.get('token','')
   create_key=os.environ.get('COCON_CREATE_KEY','')
   if not create_key or not secrets.compare_digest(str(body.get('createKey','')),create_key):return self.send(403,{'error':'creation_key_required'})
   if not isinstance(token,str) or not re.fullmatch(r'[a-zA-Z0-9_-]{40,100}',token):raise ValueError()
   box=validate_box(body['box']);family=secrets.token_urlsafe(24);now=time.time()
   with MUTEX,connect() as c:
    if c.execute('SELECT COUNT(*) FROM families').fetchone()[0]>=int(os.environ.get('COCON_MAX_FAMILIES','20')):return self.send(429,{'error':'family_limit'})
    c.execute('INSERT INTO families VALUES(?,?,?,?,?)',(family,digest(token),1,box,now))
   return self.send(201,{'id':family,'revision':1})
  parts=path.strip('/').split('/')
  if len(parts)>=3 and parts[:2]==['api','families']:
   family=parts[2]
   with connect() as c:self.auth(c,family)
   tail=parts[3:]
   if tail==['state']:
    if self.command=='GET':
     with connect() as c:r=c.execute('SELECT revision,box FROM families WHERE id=?',(family,)).fetchone()
     return self.send(200,{'revision':r['revision'],'box':json.loads(r['box'])})
    if self.command=='PUT':
     body=json.loads(self.body());box=validate_box(body['box']);expected=int(body['expectedRevision'])
     with MUTEX,connect() as c:
      c.execute('BEGIN IMMEDIATE');self.auth(c,family);old=c.execute('SELECT revision,box FROM families WHERE id=?',(family,)).fetchone()
      if old['revision']!=expected:return self.send(409,{'revision':old['revision']})
      c.execute('INSERT OR IGNORE INTO snapshots VALUES(?,?,?,?)',(family,old['revision'],old['box'],time.time()))
      c.execute('DELETE FROM snapshots WHERE family=? AND revision NOT IN (SELECT revision FROM snapshots WHERE family=? ORDER BY revision DESC LIMIT 50)',(family,family))
      c.execute('UPDATE families SET box=?,revision=?,updated=? WHERE id=?',(box,expected+1,time.time(),family))
     return self.send(200,{'revision':expected+1})
   if tail==['snapshots'] and self.command=='GET':
    with connect() as c:rows=c.execute('SELECT revision,created FROM snapshots WHERE family=? ORDER BY revision DESC LIMIT 50',(family,)).fetchall()
    return self.send(200,[dict(r) for r in rows])
   if len(tail)==2 and tail[0]=='snapshots' and tail[1].isdigit() and self.command=='GET':
    with connect() as c:r=c.execute('SELECT revision,box FROM snapshots WHERE family=? AND revision=?',(family,int(tail[1]))).fetchone()
    return self.send(200,{'revision':r['revision'],'box':json.loads(r['box'])}) if r else self.send(404)
   if len(tail)==2 and tail[0]=='blobs' and ID.fullmatch(tail[1]):
    bid=tail[1];folder=DATA/'blobs'/family;f=folder/bid
    if self.command=='PUT':
     raw=self.body(MAX_BLOB)
     with MUTEX,connect() as c:
      c.execute('BEGIN IMMEDIATE');self.auth(c,family)
      folder.mkdir(parents=True,exist_ok=True)
      total=sum(x.stat().st_size for x in folder.iterdir() if x.is_file())
      if total-(f.stat().st_size if f.exists() else 0)+len(raw)>int(os.environ.get('COCON_FAMILY_QUOTA_MB','512'))*1024*1024:return self.send(413,{'error':'storage_limit'})
      temp=folder/(bid+'.tmp');temp.write_bytes(raw);temp.replace(f)
      c.execute('INSERT OR REPLACE INTO blobs VALUES(?,?,?,?)',(family,bid,str(f),len(raw)))
     return self.send(200,{'ok':True})
    if self.command=='GET':return self.send(200,f.read_bytes(),'application/octet-stream') if f.exists() else self.send(404)
   if tail==['push'] and self.command=='POST':
    body=json.loads(self.body(250000));device=body['device'];sub=body['subscription'];schedule=body.get('schedule',{})
    if not ID.fullmatch(device) or not valid_subscription(sub) or len(schedule.get('reminders',[]))>200:raise ValueError()
    with MUTEX,connect() as c:
     c.execute('BEGIN IMMEDIATE');session=self.auth(c,family)
     c.execute("INSERT INTO push(family,device,subscription,schedule,session_digest) VALUES(?,?,?,?,?) ON CONFLICT(family,device) DO UPDATE SET subscription=excluded.subscription,schedule=excluded.schedule,session_digest=excluded.session_digest",(family,device,json.dumps(sub),json.dumps(schedule),session))
    return self.send(200,{'ok':True})
   return self.send(404)
  if path.startswith('/api/'):return self.send(404)
  if self.command not in ('GET','HEAD'):return self.send(405)
  rel=unquote(path).lstrip('/') or 'index.html';f=(PUBLIC/rel).resolve()
  if not f.is_relative_to(PUBLIC) or not f.is_file():return self.send(404,b'Not found','text/plain')
  return self.send(200,f.read_bytes(),mimetypes.guess_type(str(f))[0] or 'application/octet-stream')

def push_loop():
 try:from pywebpush import webpush,WebPushException
 except ImportError:return
 while True:
  try:
   with connect() as c:rows=c.execute('SELECT p.* FROM push p LEFT JOIN sessions s ON p.session_digest=s.digest WHERE p.session_digest IS NULL OR s.expires>?',(int(time.time()),)).fetchall()
   for row in rows:
    schedule=json.loads(row['schedule']);last=json.loads(row['last']);now=time.time();changed=False
    for r in schedule.get('reminders',[]):
     if not r.get('enabled'):continue
     rid=r.get('id','')
     try:due=next_due(r,now,last.get(rid,0),schedule.get('zone','Europe/Paris'))
     except Exception:continue
     if due is None or due>now:continue
     if is_quiet(schedule,now):last[rid]=due;changed=True;continue
     # Only a generic notification leaves the encrypted vault. No name, treatment or dose.
     try:
      key,_=vapid_keys();webpush(json.loads(row['subscription']),data=json.dumps({'title':'Petit Cocon','body':'Un rappel de votre carnet vous attend.','id':rid}),vapid_private_key=key,vapid_claims={'sub':os.environ.get('COCON_PUBLIC_ORIGIN','https://example.invalid')},timeout=8)
      last[rid]=due;changed=True
     except WebPushException as ex:
      if ex.response is not None and ex.response.status_code in (404,410):
       with connect() as c:c.execute('DELETE FROM push WHERE family=? AND device=?',(row['family'],row['device']))
     except Exception:pass
    if changed:
     with connect() as c:c.execute('UPDATE push SET last=? WHERE family=? AND device=?',(json.dumps(last),row['family'],row['device']))
  except Exception:pass
  time.sleep(20)

def main():
 init_db();threading.Thread(target=push_loop,daemon=True).start()
 ThreadingHTTPServer(('0.0.0.0',int(os.environ.get('PORT','8080'))),Handler).serve_forever()
if __name__=='__main__':main()
