(function (root, factory) {
  const api = factory();
  if (typeof module === 'object' && module.exports) module.exports = api;
  else root.CoconModel = api;
})(typeof globalThis !== 'undefined' ? globalThis : this, function () {
  'use strict';
  const TYPES = ['feed','bottle','diaper','sleep','pump','meal','growth','temperature','medicine','note','bath','vaccine','milestone','tooth','allergy','prescription','appointment','checkin'];
  const uid = () => 'c' + Date.now().toString(36) + Math.random().toString(36).slice(2,10);
  const dayStart = (t) => { const d=new Date(t); d.setHours(0,0,0,0); return +d; };
  const nextDay = (t) => { const d=new Date(dayStart(t)); d.setDate(d.getDate()+1); return +d; };
  function fresh() {
    const id=uid();
    return {version:1,schema:2,attachments:[],deleted:{},babies:[{id,name:'Mon bébé',birthDate:'',emoji:'🌱',sex:'',gestationWeeks:40,updatedAt:1}],selectedBabyId:id,records:[],timers:[],reminders:[],settings:{theme:'light',onboarded:false,quietStart:'',quietEnd:'',autoBackup:true}};
  }
  function timerValue(t,now=Date.now()) {
    const extra=t.running ? Math.max(0,now-t.markAt) : 0;
    const left=t.leftMs+(t.type==='feed' && t.side==='left'?extra:0);
    const right=t.rightMs+(t.type==='feed' && t.side==='right'?extra:0);
    return {leftMs:left,rightMs:right,durationMs:t.type==='feed'?left+right:t.elapsedMs+extra};
  }
  function summary(records,timers,babyId,at=Date.now(),now=Date.now()) {
    const start=dayStart(at), end=nextDay(at), rs=records.filter(r=>r.babyId===babyId), day=rs.filter(r=>r.at>=start&&r.at<end);
    const sum=(type,key)=>day.filter(r=>r.type===type).reduce((n,r)=>n+(Number(r[key])||0),0);
    let sleepMs=0;
    const intervals=[];
    rs.filter(r=>r.type==='sleep').forEach(r=>intervals.push([Math.max(r.at,start),Math.min(r.end||r.at+r.durationMs,end)]));
    timers.filter(t=>t.babyId===babyId&&t.type==='sleep').forEach(t=>intervals.push([Math.max(t.startedAt,start),Math.min(now,end)]));
    // Merge overlaps so correcting an entry cannot double-count sleep.
    const sorted=intervals.filter(x=>x[1]>x[0]).sort((a,b)=>a[0]-b[0]);
    let range=null;
    for(const i of sorted){if(!range)range=i.slice();else if(i[0]<=range[1])range[1]=Math.max(range[1],i[1]);else{sleepMs+=range[1]-range[0];range=i.slice();}}
    if(range)sleepMs+=range[1]-range[0];
    return {feeds:day.filter(r=>r.type==='feed').length,feedMs:sum('feed','durationMs'),bottles:day.filter(r=>r.type==='bottle').length,milkMl:sum('bottle','amount'),pumpMl:sum('pump','amount'),diapers:day.filter(r=>r.type==='diaper').length,wet:day.filter(r=>r.type==='diaper'&&['wet','both'].includes(r.diaper)).length,dirty:day.filter(r=>r.type==='diaper'&&['dirty','both'].includes(r.diaper)).length,sleepMs,day};
  }
  function validate(input) {
    const raw=input&&input.app==='Petit Cocon'?input.data:input;
    if(!raw||raw.version!==1||!Array.isArray(raw.babies)||!raw.babies.length||raw.babies.length>20)throw Error('Sauvegarde Petit Cocon non reconnue.');
    const text=(v,n=1000)=>typeof v==='string'?v.slice(0,n):'';
    const id=v=>{if(typeof v!=='string'||!/^[-a-zA-Z0-9_]{1,100}$/.test(v))throw Error('Identifiant invalide.');return v;};
    const stamp=v=>{if(typeof v!=='number'||!Number.isFinite(v)||v<1||v>4102444800000)throw Error('Date invalide dans la sauvegarde.');return v;};
    const num=(v,max=1e12)=>{if(typeof v!=='number'||!Number.isFinite(v)||v<0||v>max)throw Error('Valeur invalide dans la sauvegarde.');return v;};
    const clock=(v,fallback=1)=>Number.isFinite(Number(v))&&Number(v)>0&&Number(v)<4102444800000?Number(v):fallback;
    const seen=new Set();
    function unique(v){v=id(v);if(seen.has(v))throw Error('Identifiants en double.');seen.add(v);return v;}
    const babies=raw.babies.map(b=>({id:unique(b.id),updatedAt:clock(b.updatedAt),sex:['female','male'].includes(b.sex)?b.sex:'',gestationWeeks:Number(b.gestationWeeks)||40,name:text(b.name,80).trim()||'Mon bébé',birthDate:/^\d{4}-\d{2}-\d{2}$/.test(b.birthDate)&&!isNaN(Date.parse(b.birthDate))?b.birthDate:'',emoji:['🌱','🌸','🐻','🌙','🦊','🐣'].includes(b.emoji)?b.emoji:'🌱'}));
    const belongs=v=>{if(!babies.some(b=>b.id===v))throw Error('Profil manquant dans la sauvegarde.');return v;};
    if(!Array.isArray(raw.records)||raw.records.length>100000||!Array.isArray(raw.reminders)||raw.reminders.length>200||!Array.isArray(raw.timers)||raw.timers.length>40)throw Error('Structure ou taille de sauvegarde invalide.');
    const records=raw.records.map(r=>{
      if(!TYPES.includes(r.type))throw Error('Type de suivi inconnu.');
      const out={id:unique(r.id),babyId:belongs(r.babyId),type:r.type,at:stamp(r.at),notes:text(r.notes,10000),updatedAt:clock(r.updatedAt,r.at)};
      for(const k of ['durationMs','leftMs','rightMs','amount','weight','height','head','temperature','doseMg','concentration','doseMl','doseMgPerKg','prescribedWeight','intervalHours','maxDailyMg','doseIndex','ageMonths'])if(r[k]!==undefined&&r[k]!==null)out[k]=num(r[k]);
      if(r.end!==undefined){out.end=stamp(r.end);if(out.end<out.at)throw Error('Fin du sommeil antérieure au début.');}
      for(const k of ['milk','diaper','food','medicine','dose','label','vaccineCode','product','batch','doctor','milestone','tooth','reaction','severity','prescriptionId','reminderId','scheduleId','substance','route','endDate','birthDate','sex'])if(r[k]!==undefined)out[k]=text(r[k],500);
      out.attachmentIds=Array.isArray(r.attachmentIds)?r.attachmentIds.filter(v=>typeof v==='string'&&/^[-a-zA-Z0-9_]{1,100}$/.test(v)).slice(0,20):[];
      out.allergens=Array.isArray(r.allergens)?r.allergens.map(v=>text(v,80)).slice(0,30):[];
      return out;
    });
    const timers=raw.timers.map(t=>{
      if(!['feed','sleep'].includes(t.type))throw Error('Chronomètre inconnu.');
      return {id:unique(t.id),babyId:belongs(t.babyId),type:t.type,startedAt:stamp(t.startedAt),markAt:stamp(t.markAt),running:!!t.running,side:t.side==='right'?'right':'left',leftMs:num(t.leftMs||0),rightMs:num(t.rightMs||0),elapsedMs:num(t.elapsedMs||0),updatedAt:clock(t.updatedAt,t.markAt)};
    });
    const timerKeys=new Set();for(const t of timers){const k=t.babyId+t.type;if(timerKeys.has(k))throw Error('Chronomètres en double.');timerKeys.add(k);}
    const reminders=raw.reminders.map(r=>({id:unique(r.id),babyId:belongs(r.babyId),title:text(r.title,120)||'Rappel',category:['feeding','care','appointment','other'].includes(r.category)?r.category:'other',at:stamp(r.at),repeat:['once','daily','interval','weekly','monthly'].includes(r.repeat)?r.repeat:'once',intervalMinutes:Math.max(1,Math.min(525600,Number(r.intervalMinutes)||180)),hour:Number.isInteger(r.hour)&&r.hour>=0&&r.hour<=23?r.hour:new Date(r.at).getHours(),minute:Number.isInteger(r.minute)&&r.minute>=0&&r.minute<=59?r.minute:new Date(r.at).getMinutes(),weekdays:Array.isArray(r.weekdays)?r.weekdays.filter(v=>Number.isInteger(v)&&v>=0&&v<=6):[],monthDay:Math.max(1,Math.min(31,Number(r.monthDay)||new Date(r.at).getDate())),untilAt:typeof r.untilAt==='number'&&Number.isFinite(r.untilAt)?r.untilAt:0,updatedAt:clock(r.updatedAt,r.at),feedAnchorAt:typeof r.feedAnchorAt==='number'&&Number.isFinite(r.feedAnchorAt)?r.feedAnchorAt:0,logCompletion:r.logCompletion!==false,prescriptionId:text(r.prescriptionId,100),enabled:!!r.enabled,resetOnFeed:!!r.resetOnFeed}));
    const attachments=(Array.isArray(raw.attachments)?raw.attachments:[]).slice(0,2000).map(a=>({id:unique(a.id),babyId:belongs(a.babyId),name:text(a.name,200),mime:text(a.mime,100),size:num(a.size||0,30*1024*1024),updatedAt:clock(a.updatedAt)}));
    const deleted={};for(const [k,v] of Object.entries(raw.deleted||{}))if(/^[-a-zA-Z0-9_:]{1,130}$/.test(k)&&typeof v==='number'&&Number.isFinite(v))deleted[k]=v;
    return {version:1,schema:2,attachments,deleted,babies,selectedBabyId:babies.some(b=>b.id===raw.selectedBabyId)?raw.selectedBabyId:babies[0].id,records,timers,reminders,settings:{theme:raw.settings?.theme==='dark'?'dark':'light',onboarded:!!raw.settings?.onboarded,quietStart:text(raw.settings?.quietStart,5),quietEnd:text(raw.settings?.quietEnd,5),autoBackup:raw.settings?.autoBackup!==false}};
  }
  function csv(records,babies) {
    const labels={feed:'Tétée',bottle:'Biberon',diaper:'Couche',sleep:'Sommeil',pump:'Tirage',meal:'Repas',growth:'Croissance',temperature:'Température',medicine:'Médicament',note:'Note',bath:'Bain',vaccine:'Vaccin',milestone:'Étape',tooth:'Dent',allergy:'Réaction',prescription:'Ordonnance',appointment:'Rendez-vous',checkin:'Rappel effectué'};
    const safe=v=>{let s=String(v??'');if(/^[=+@\-\t\r]/.test(s))s="'"+s;return '"'+s.replace(/"/g,'""')+'"';};
    const rows=[['Bébé','Type','Date ISO','Date locale','Fin ISO','Durée (min)','Gauche (min)','Droite (min)','Volume (ml)','Lait','Couche','Poids (kg)','Taille (cm)','Périmètre crânien (cm)','Température (°C)','Aliment','Médicament','Dose notée','Notes','Identifiant','Profil ID','Données JSON']];
    for(const r of [...records].sort((a,b)=>a.at-b.at))rows.push([babies.find(b=>b.id===r.babyId)?.name,labels[r.type],new Date(r.at).toISOString(),new Date(r.at).toLocaleString('fr-FR'),r.end?new Date(r.end).toISOString():'',r.durationMs!=null?+(r.durationMs/60000).toFixed(2):'',r.leftMs!=null?+(r.leftMs/60000).toFixed(2):'',r.rightMs!=null?+(r.rightMs/60000).toFixed(2):'',r.amount,r.milk,({wet:'Urine',dirty:'Selles',both:'Urine et selles',dry:'Sèche'})[r.diaper]||'',r.weight,r.height,r.head,r.temperature,r.food,r.medicine,r.dose,r.notes,r.id,r.babyId,JSON.stringify(r)]);
    return '\uFEFF'+rows.map(row=>row.map(safe).join(';')).join('\r\n');
  }
  return {TYPES,uid,fresh,validate,summary,dayStart,nextDay,timerValue,csv};
});
