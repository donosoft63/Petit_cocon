/* Account authentication and the per-account encrypted copy of the family key. */
window.CoconAccounts = (() => {
  'use strict';
  const P = window.CoconPlatform;
  const utf8 = new TextEncoder();
  const text = new TextDecoder();
  const tokenPattern = /^[A-Za-z0-9_-]{43}$/;
  const familyPattern = /^[A-Za-z0-9_-]{12,100}$/;
  const messages = {
    invalid_credentials: 'L’adresse e-mail ou le mot de passe est incorrect.',
    unauthorized: 'Ta session a expiré ou l’accès a été retiré. Reconnecte-toi.',
    invalid_invitation: 'Cette invitation a expiré, a été utilisée ou a été annulée.',
    creation_key_required: 'Le code de création du serveur est incorrect.',
    legacy_access_required: 'Ce carnet V2 a déjà été migré ou son accès est invalide. Essaie de te connecter.',
    email_in_use: 'Un compte utilise déjà cette adresse sur ce serveur. Connecte-toi avec ce compte.',
    owner_required: 'Seul le propriétaire peut gérer les accès.',
    member_limit: 'Ce carnet a atteint la limite de comptes ou d’invitations.',
    family_limit: 'Ce serveur a atteint la limite de carnets.',
    password_unchanged: 'Choisis un mot de passe différent.',
    too_many_attempts: 'Trop de tentatives. Réessaie dans quelques minutes.',
    try_again: 'Le serveur traite déjà des connexions. Réessaie dans un instant.',
    not_found: 'Cet accès a déjà été retiré.'
  };

  function serverOrigin(address) {
    const origin = P.endpoint(String(address).trim(), '');
    if (!P.N && origin !== location.origin) {
      throw Error('Ouvre ' + origin + ' dans ton navigateur pour utiliser ce serveur.');
    }
    return origin;
  }

  async function api(server, path, {method = 'GET', body, token} = {}) {
    let response;
    try {
      response = await fetch(P.endpoint(server, '/api/accounts/' + path), {
        method,
        body: body === undefined ? undefined : JSON.stringify(body),
        headers: {
          ...(body === undefined ? {} : {'Content-Type': 'application/json'}),
          ...(token ? {Authorization: 'Bearer ' + token} : {})
        },
        cache: 'no-store',
        redirect: 'error',
        credentials: 'omit',
        signal: AbortSignal.timeout(20000)
      });
    } catch {
      throw Error('Serveur injoignable. Vérifie son adresse HTTPS et ta connexion.');
    }
    if (response.status === 404 && path === 'parameters') {
      throw Error('Mets à jour Petit Cocon sur le serveur pour utiliser les comptes.');
    }
    const result = await response.json().catch(() => ({}));
    if (!response.ok) {
      throw Object.assign(Error(messages[result.error] || 'Échange impossible avec le serveur (' + response.status + ').'),
        {status: response.status, code: result.error});
    }
    return result;
  }

  function normalizeEmail(value) {
    const email = String(value).trim().toLowerCase();
    if (email.length > 254 || !/^[!-?A-~]+@[!-?A-~]+$/.test(email)) {
      throw Error('Renseigne une adresse e-mail valide.');
    }
    return email;
  }

  function checkPassword(password, minimum = 1) {
    if ([...password].length < minimum || utf8.encode(password).length > 1024) {
      throw Error(minimum > 1 ? 'Choisis un mot de passe d’au moins 12 caractères.' : 'Mot de passe invalide.');
    }
  }

  async function material(salt, email, password) {
    checkPassword(password);
    if (!tokenPattern.test(salt)) throw Error('Ce serveur ne prend pas en charge les comptes.');
    const input = await crypto.subtle.importKey('raw', utf8.encode(password), 'PBKDF2', false, ['deriveBits']);
    const root = await crypto.subtle.deriveBits({
      name: 'PBKDF2', hash: 'SHA-256', iterations: 600000,
      salt: utf8.encode('Petit Cocon comptes v1\n' + salt + '\n' + normalizeEmail(email))
    }, input, 256);
    const hmac = await crypto.subtle.importKey('raw', root, {name: 'HMAC', hash: 'SHA-256'}, false, ['sign']);
    const proof = await crypto.subtle.sign('HMAC', hmac, utf8.encode('cocon/auth/v1'));
    const wrap = await crypto.subtle.sign('HMAC', hmac, utf8.encode('cocon/wrap/v1'));
    return {proof: P.url64(proof), wrap: await P.aes(wrap)};
  }

  async function parameters(server) {
    const info = await api(server, 'parameters');
    if (info.version !== 1 || !tokenPattern.test(info.salt)) {
      throw Error('Ce serveur ne prend pas en charge les comptes.');
    }
    return info.salt;
  }

  function familyConfig(server, session, key) {
    if (!familyPattern.test(session.family) || !tokenPattern.test(session.token) ||
        !session.account?.id || !Number.isFinite(session.expiresAt) || key.length !== 32) {
      throw Error('Réponse du serveur incompatible.');
    }
    return {
      mode: 'account', server, id: session.family, token: session.token,
      key: P.b64(key), account: session.account, expiresAt: session.expiresAt
    };
  }

  async function readJournal(family, box) {
    const encrypted = box || (await P.request('/state', {}, family)).box;
    const data = await P.open(encrypted, await P.aes(P.un64(family.key)));
    return CoconModel.validate(JSON.parse(text.decode(data)));
  }

  async function login(server, email, password) {
    server = serverOrigin(server);
    email = normalizeEmail(email);
    const {proof, wrap} = await material(await parameters(server), email, password);
    const session = await api(server, 'login', {method: 'POST', body: {email, proof}});
    try {
      P.checkJournalFamily(session.family);
      const family = familyConfig(server, session, await P.open(session.envelope, wrap));
      return {family, state: await readJournal(family)};
    } catch (error) {
      await P.endAccountSession({server, token: session.token});
      throw error;
    }
  }

  async function register({server, name, email, password, setupKey, state, legacy, invitation}) {
    server = serverOrigin(server);
    email = normalizeEmail(email);
    checkPassword(password, 12);
    let key, remote, form;
    if (invitation) {
      P.checkJournalFamily(invitation.id);
      const check = await api(server, 'invitations/check', {method: 'POST', body: {invite: invitation.invite}});
      if (check.family !== invitation.id) throw Error('Ce code correspond à un autre carnet.');
      key = P.un64(invitation.key);
      remote = await readJournal({key: invitation.key}, check.box);
      form = {mode: 'invite', invite: invitation.invite};
    } else if (legacy) {
      P.checkJournalFamily(legacy.id);
      key = P.un64(legacy.key);
      remote = await readJournal(legacy);
      form = {mode: 'claim', family: legacy.id, legacyToken: legacy.token, setupKey};
    } else {
      P.checkJournalFamily('');
      key = P.random(32);
      form = {mode: 'create', setupKey, box: await P.seal(JSON.stringify(state), await P.aes(key))};
    }
    const {proof, wrap} = await material(await parameters(server), email, password);
    const session = await api(server, 'register', {
      method: 'POST', body: {...form, email, name, proof, envelope: await P.seal(key, wrap)}
    });
    return {family: familyConfig(server, session, key), state: remote};
  }

  function parseInvitation(code) {
    const value = code.trim();
    if (!value.startsWith('PC3.') || value.length > 2048) throw Error('Code d’invitation PC3 non reconnu.');
    let result;
    try {
      result = JSON.parse(text.decode(P.fromUrl(value.slice(4))));
      if (!familyPattern.test(result.id) || !tokenPattern.test(result.invite) || P.un64(result.key).length !== 32) {
        throw Error();
      }
    } catch {
      throw Error('Code d’invitation incomplet.');
    }
    return {...result, server: serverOrigin(result.server)};
  }

  function authenticated(path, method = 'GET', body) {
    const family = P.config.family;
    return api(family.server, path, {method, body, token: family.token});
  }

  async function createInvitation() {
    const {id, expires, invite} = await authenticated('invitations', 'POST');
    const family = P.config.family;
    const payload = {server: family.server, id: family.id, invite, key: family.key};
    return {id, expires, code: 'PC3.' + P.url64(utf8.encode(JSON.stringify(payload)))};
  }

  async function changePassword(current, next) {
    checkPassword(next, 12);
    const family = P.config.family;
    const salt = await parameters(family.server);
    const prior = await material(salt, family.account.email, current);
    const {proof, wrap} = await material(salt, family.account.email, next);
    const envelope = await P.seal(P.un64(family.key), wrap);
    return authenticated('password', 'POST', {currentProof: prior.proof, proof, envelope});
  }

  return {
    normalizeEmail, material, login, register, parseInvitation, createInvitation, changePassword,
    members: () => authenticated('members'),
    removeMember: id => authenticated('members/' + encodeURIComponent(id), 'DELETE'),
    cancelInvitation: id => authenticated('invitations/' + encodeURIComponent(id), 'DELETE')
  };
})();
