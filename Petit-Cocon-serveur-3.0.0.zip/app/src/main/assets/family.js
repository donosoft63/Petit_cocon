window.CoconFamily = (() => {
  'use strict';
  const P = window.CoconPlatform;
  const Accounts = window.CoconAccounts;
  const app = () => window.Cocon;

  const button = (label, action, style = 'secondary', id = '') =>
    `<button type="button" class="button ${style}" data-action="${action}" data-id="${app().esc(id)}">${label}</button>`;

  function view() {
    const {esc} = app();
    const {family, lastSync, error, journalFamily} = P.config;
    const account = family?.account;
    const needsLogin = P.needsLogin();
    let panel;
    if (!family) {
      panel = `<h2>Retrouver ton carnet</h2>
        <p class="muted">Connecte-toi sur le serveur de ta famille pour partager le journal et les rappels.</p>
        <div class="stack family-actions">
          ${button('Se connecter', 'v3-login', 'primary')}
          ${button('Rejoindre avec une invitation', 'v3-join')}
          ${journalFamily ? '' : button('Créer le premier compte', 'v3-create')}
          ${button('Utiliser un code V2', 'v2-join-family', 'quiet')}
        </div>`;
    } else {
      panel = `<h2>${account ? esc(account.name) : 'Carnet partagé V2'}</h2>
        ${account ? `<p class="muted family-address">${esc(account.email)} · ${account.role === 'owner' ? 'Propriétaire' : 'Parent'}</p>` : ''}
        <p class="small muted family-address">${esc(family.server)}</p>
        <p class="small muted">Dernier échange ${lastSync ? new Date(lastSync).toLocaleString('fr-FR') : 'en attente'}</p>
        ${needsLogin ? '<p class="error" role="status">Reconnecte-toi pour reprendre les échanges.</p>' : error ? `<p class="error" role="status">${esc(error)}</p>` : ''}
        <div class="stack family-actions">
          ${needsLogin ? button('Se reconnecter', 'v3-login', 'primary') : button('Synchroniser maintenant', 'v2-sync', 'primary')}
          ${!account ? button('Activer les comptes sur ce carnet', 'v3-create') + button('Afficher le code de partage V2', 'v2-invitation') + button('Se connecter à un compte', 'v3-login') : ''}
          ${account?.role === 'owner' && !needsLogin ? button('Inviter un parent', 'v3-invite') : ''}
          ${account && !needsLogin ? button('Accès au carnet', 'v3-members') + button('Changer mon mot de passe', 'v3-password') : ''}
          ${needsLogin ? '' : button('Historique distant', 'v2-remote-history')}
          ${button('Déconnecter cet appareil', 'v2-disconnect', 'quiet')}
        </div>`;
    }
    return `<div class="page-head"><div><h1>Entre parents</h1><p>Le même carnet sur les appareils de ta famille.</p></div></div>
      <div class="panel family-panel">${panel}</div>
      <p class="hint family-actions">Les données du carnet et les fichiers joints sont chiffrés sur tes appareils. Les ajouts hors connexion sont envoyés au prochain échange.</p>`;
  }

  function modal(name, data) {
    const {esc, field, wrapper} = app();
    const active = P.config.family;
    const form = (title, content, label, action) =>
      wrapper(title, content, `<button class="button" type="submit">${label}</button>`, action);
    const origin = (P.N ? active?.server || P.config.accountServer : location.origin) || '';
    const address = field('Adresse HTTPS du serveur', 'server', origin, 'url',
      'required maxlength="255" placeholder="https://cocon.example.fr" autocomplete="url"');
    const email = field('Adresse e-mail', 'email', active?.account?.email || '', 'email',
      'required maxlength="254" autocomplete="username" autocapitalize="none"');
    const password = (label, name, isNew = false) => field(label, name, '', 'password',
      `required maxlength="256" autocomplete="${isNew ? 'new-password' : 'current-password'}" ${isNew ? 'minlength="12"' : ''}`);

    if (name === 'v3-login') {
      return form('Se connecter', address + email + password('Mot de passe', 'password') +
        '<p class="hint">Le carnet de cet appareil sera fusionné avec celui du compte.</p>',
        'Se connecter', 'v3-login-form');
    }
    if (name === 'v3-create' || name === 'v3-join-account') {
      const joining = name === 'v3-join-account';
      const legacy = !joining && active && !active.account;
      const server = joining ? data.invitation.server : legacy ? active.server : '';
      const fields = server ? `<p class="hint family-address">Serveur <strong>${esc(server)}</strong></p>` : address;
      const setup = joining ? '' : field('Code de création du serveur', 'setupKey', '', 'password',
        'required maxlength="150" autocomplete="off"', 'Le code COCON_CREATE_KEY se trouve dans le fichier .env du serveur.');
      const note = joining
        ? 'Ton carnet local sera fusionné avec le carnet partagé lors de la création du compte.'
        : legacy
          ? 'Le carnet, ses fichiers et son historique sont conservés. Les autres appareils devront se reconnecter avec un compte.'
          : 'Ce compte pourra inviter d’autres parents. Le carnet présent sur cet appareil sera envoyé chiffré au serveur.';
      return form(joining ? 'Créer ton compte parent' : legacy ? 'Activer les comptes' : 'Créer le premier compte',
        fields + field('Ton prénom', 'name', '', 'text', 'required maxlength="80" autocomplete="given-name"') + email +
        password('Mot de passe · 12 caractères minimum', 'password', true) +
        password('Confirmer le mot de passe', 'confirmation', true) + setup + `<p class="hint">${note}</p>`,
        legacy ? 'Activer les comptes' : 'Créer le compte', joining ? 'v3-join-account-form' : 'v3-create-form');
    }
    if (name === 'v3-join') {
      return form('Rejoindre avec une invitation',
        '<label class="field"><span>Code d’invitation</span><textarea name="code" rows="4" maxlength="2048" required autocomplete="off" autocapitalize="none" spellcheck="false" placeholder="PC3.…"></textarea></label><p class="hint">Colle le code reçu du propriétaire du carnet.</p>',
        'Continuer', 'v3-join-form');
    }
    if (name === 'v3-invite') {
      return wrapper('Invitation prête',
        `<p class="hint">Ce code permet une seule inscription. Il expire le ${new Date(data.expires * 1000).toLocaleString('fr-FR')}. Transmets-le au parent que tu veux inviter.</p>
         <label class="field"><span>Code d’invitation</span><textarea id="account-invite-code" readonly rows="4">${esc(data.code)}</textarea></label>`,
        button('Copier le code', 'v3-copy-invite', 'primary'));
    }
    if (name === 'v3-members') {
      const members = data.members.map(member => `<div class="family-access">
        <div class="family-address"><strong>${esc(member.name)}</strong><small>${esc(member.email)} · ${member.role === 'owner' ? 'Propriétaire' : 'Parent'}</small></div>
        ${active?.account?.role === 'owner' && member.role === 'parent' ? button('Retirer', 'v3-remove', 'compact secondary', member.id) : ''}
      </div>`).join('');
      const list = data.invitations || [];
      const invitations = list.length ? `<h3 class="family-actions">Invitations en attente</h3>${list.map(invite => `<div class="family-access">
        <small>Expire le ${new Date(invite.expires * 1000).toLocaleString('fr-FR')}</small>
        ${button('Annuler', 'v3-cancel-invite', 'compact secondary', invite.id)}</div>`).join('')}` : '';
      return wrapper('Accès au carnet', members + invitations);
    }
    if (name === 'v3-password') {
      return form('Changer mon mot de passe',
        password('Mot de passe actuel', 'current') + password('Nouveau mot de passe', 'password', true) +
        password('Confirmer le nouveau mot de passe', 'confirmation', true) +
        '<p class="hint">Tes autres appareils devront se reconnecter après le changement.</p>',
        'Enregistrer', 'v3-password-form');
    }
    return null;
  }

  function mergeJournal(local, remote) {
    const baby = local.babies[0];
    const isPlaceholder = local.babies.length === 1 && baby.updatedAt === 1 && baby.name === 'Mon bébé' &&
      !baby.birthDate && !baby.sex && baby.emoji === '🌱' && baby.gestationWeeks === 40 &&
      ['records', 'reminders', 'timers', 'attachments'].every(key => !local[key]?.length) &&
      !Object.keys(local.deleted || {}).length;
    const state = isPlaceholder ? {...remote, settings: {...local.settings}} : CoconCore.merge(local, remote);
    return {state, replace: isPlaceholder};
  }

  async function connect(result) {
    const A = app();
    try {
      await P.associateJournal(result.family.id);
      const {state, replace} = result.state ? mergeJournal(A.state, result.state) : {state: A.state, replace: false};
      state.settings.onboarded = true;
      if (!A.setState(state, true, replace)) throw Error('Le carnet local n’a pas pu être enregistré.');
      await P.flush();
      await P.linkFamily(result.family);
    } catch (error) {
      await P.endAccountSession(result.family);
      throw error;
    }
    A.closeModal();
    A.setView('v2:family');
    A.toast('Compte connecté.');
    P.sync(() => A.state, data => A.setState(data, true))
      .then(success => { if (success) { A.render(); A.toast('Carnet synchronisé.'); } })
      .catch(() => A.render());
  }

  async function handle(action, id) {
    const A = app();
    switch (action) {
      case 'v3-start':
        A.closeModal();
        A.setView('v2:family');
        break;
      case 'v3-login':
      case 'v3-create':
      case 'v3-join':
      case 'v3-password':
        A.openModal(action);
        break;
      case 'v3-invite':
        A.openModal(action, await Accounts.createInvitation());
        break;
      case 'v3-copy-invite':
        if (P.N) P.N.shareText(A.modal.data.code);
        else if (navigator.clipboard) await navigator.clipboard.writeText(A.modal.data.code);
        else {
          document.querySelector('#account-invite-code').select();
          document.execCommand('copy');
        }
        A.toast('Code prêt à partager.');
        break;
      case 'v3-members':
        A.openModal(action, await Accounts.members());
        break;
      case 'v3-remove': {
        const member = A.modal.data.members.find(item => item.id === id);
        A.confirm('Retirer cet accès ?', `${member.name} ne pourra plus synchroniser ce carnet. Les données déjà reçues restent sur ses appareils.`, async () => {
          try {
            await Accounts.removeMember(id);
            A.openModal('v3-members', await Accounts.members());
            A.toast('Accès retiré.');
          } catch (error) { A.toast(error.message); }
        }, true, 'Retirer');
        break;
      }
      case 'v3-cancel-invite':
        await Accounts.cancelInvitation(id);
        A.openModal('v3-members', await Accounts.members());
        A.toast('Invitation annulée.');
        break;
    }
  }

  async function submit(form) {
    const A = app();
    const data = new FormData(form);
    const submitter = form.querySelector('button[type="submit"]');
    const currentModal = A.modal;
    const value = key => String(data.get(key) || '');
    if (submitter) submitter.disabled = true;
    try {
      if (form.id === 'v3-login-form') {
        return await connect(await Accounts.login(value('server'), value('email'), value('password')));
      }
      if (form.id === 'v3-join-form') {
        const invitation = Accounts.parseInvitation(value('code'));
        P.checkJournalFamily(invitation.id);
        A.openModal('v3-join-account', {invitation});
        return;
      }
      if (value('password') !== value('confirmation')) throw Error('Les deux mots de passe sont différents.');
      if (form.id === 'v3-password-form') {
        await Accounts.changePassword(value('current'), value('password'));
        A.closeModal();
        A.toast('Mot de passe mis à jour.');
        return;
      }
      const invitation = currentModal?.data.invitation;
      const active = P.config.family;
      const legacy = !invitation && active && !active.account ? active : undefined;
      await connect(await Accounts.register({
        server: invitation?.server || legacy?.server || value('server'),
        email: value('email'), name: value('name'), password: value('password'), setupKey: value('setupKey'),
        state: A.state, legacy, invitation
      }));
    } catch (error) {
      if (A.modal === currentModal) A.formError(error.message);
      else A.toast(error.message);
    } finally {
      if (submitter) submitter.disabled = false;
    }
  }

  return {view, modal, handle, submit, mergeJournal};
})();
