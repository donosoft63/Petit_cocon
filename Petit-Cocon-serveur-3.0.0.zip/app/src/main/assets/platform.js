/* Local encrypted browser vault, native adapter, encrypted sharing, portable ZIP backups. */
window.CoconPlatform=(()=>{
 'use strict';const N=window.CoconNative||null,enc=new TextEncoder(),dec=new TextDecoder();
 let db,key,rawKey,raw='',cfg={},syncing=false,saveQueue=Promise.resolve(),configQueue=Promise.resolve(),autoTimer,failed=false,stagedFiles=null,pendingFamily=null,hasLock=false,hiddenAt=0,changingFamily=false;
 const bytes=v=>typeof v==='string'?enc.encode(v):v instanceof Uint8Array?v:new Uint8Array(v);
 const b64=v=>{let s='';for(const b of bytes(v))s+=String.fromCharCode(b);return btoa(s);};
 const un64=v=>Uint8Array.from(atob(v),c=>c.charCodeAt(0));
 const random=n=>crypto.getRandomValues(new Uint8Array(n));
 const url64=v=>b64(v).replace(/\+/g,'-').replace(/\//g,'_').replace(/=+$/,'');
 const fromUrl=v=>un64(v.replace(/-/g,'+').replace(/_/g,'/')+'='.repeat((4-v.length%4)%4));
 const aes=raw=>crypto.subtle.importKey('raw',bytes(raw),'AES-GCM',false,['encrypt','decrypt']);
 async function seal(v,k=key){const iv=random(12),cipher=await crypto.subtle.encrypt({name:'AES-GCM',iv},k,bytes(v));return {iv:b64(iv),ciphertext:b64(cipher)};}
 async function open(box,k=key){return new Uint8Array(await crypto.subtle.decrypt({name:'AES-GCM',iv:un64(box.iv)},k,un64(box.ciphertext)));}
 async function pinKey(pin,salt){const k=await crypto.subtle.importKey('raw',enc.encode(pin),'PBKDF2',false,['deriveKey']);return crypto.subtle.deriveKey({name:'PBKDF2',hash:'SHA-256',salt,iterations:250000},k,{name:'AES-GCM',length:256},false,['encrypt','decrypt']);}
 function store(op,id,value){return new Promise((resolve,reject)=>{const t=db.transaction('vault',op==='get'?'readonly':'readwrite'),s=t.objectStore('vault');let result;const r=op==='get'?s.get(id):op==='delete'?s.delete(id):s.put(value,id);r.onsuccess=()=>{result=r.result;};r.onerror=()=>reject(r.error);t.oncomplete=()=>resolve(result);t.onabort=t.onerror=()=>reject(t.error||Error('Écriture interrompue.'));});}
 async function unlock(meta){
  const el=document.createElement('div');el.className='lock-screen';el.innerHTML='<div class="panel"><div class="welcome-art">🌱</div><h2>Votre cocon est verrouillé</h2><p class="muted">Saisis ton code pour retrouver le carnet.</p><form><label class="field"><span>Code personnel</span><input type="password" inputmode="numeric" autocomplete="off" required minlength="6" maxlength="12"></label><p role="alert" class="lock-error"></p><button class="button full">Déverrouiller</button></form><p class="small muted" style="margin-top:15px">Sans le code, les données locales chiffrées ne peuvent pas être récupérées. Une sauvegarde externe reste réimportable.</p></div>';
  document.body.append(el);let attempts=0;
  return new Promise(resolve=>el.querySelector('form').onsubmit=async e=>{e.preventDefault();const button=el.querySelector('button');button.disabled=true;try{const pk=await pinKey(el.querySelector('input').value,un64(meta.salt));rawKey=await open(meta.box,pk);key=await aes(rawKey);el.remove();resolve();}catch(err){attempts++;el.querySelector('.lock-error').textContent='Code incorrect.';await new Promise(r=>setTimeout(r,Math.min(30000,attempts*1000)));button.disabled=false;}});
 }
 async function init(){
  if(N){cfg=JSON.parse(N.getConfig?.()||'{}');return;}
  if(!window.crypto?.subtle)throw Error('Ouvre cette application sur une adresse HTTPS pour utiliser le coffre chiffré.');
  db=await new Promise((resolve,reject)=>{const r=indexedDB.open('petit-cocon-private-v2',1);r.onupgradeneeded=()=>r.result.createObjectStore('vault');r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);});
  const meta=await store('get','pin');hasLock=!!meta;if(meta)await unlock(meta);else{let v=await store('get','deviceKey');if(!v){v=b64(random(32));await store('put','deviceKey',v);}rawKey=un64(v);key=await aes(rawKey);}
  const box=await store('get','state');raw=box?dec.decode(await open(box)):localStorage.getItem('petit-cocon-v1')||'';
  const cb=await store('get','config');cfg=cb?JSON.parse(dec.decode(await open(cb))):{};if(raw&&!box){await store('put','state',await seal(raw));localStorage.removeItem('petit-cocon-v1');}
  if('serviceWorker'in navigator)navigator.serviceWorker.register('sw.js').catch(()=>{});
  document.addEventListener('visibilitychange',()=>{if(!hasLock)return;if(document.hidden){hiddenAt=Date.now();document.getElementById('app').style.visibility='hidden';}else if(hiddenAt&&Date.now()-hiddenAt>60000)location.reload();else document.getElementById('app').style.visibility='';});
 }
 function load(){return raw;}
 function toast(v){window.App?.toast(v);}
 function save(v){raw=v;saveQueue=saveQueue.then(async()=>{await store('put','state',await seal(v));const state=JSON.parse(v);if(state.settings?.autoBackup!==false)await localSnapshot(state);failed=false;}).catch(e=>{failed=true;toast('Échec de sauvegarde locale. Exporte une copie avant de fermer.');});return true;}
 async function flush(){await saveQueue;if(failed)throw Error('Échec de sauvegarde locale.');}
 async function setConfig(next){
  const before=cfg,value=JSON.stringify(next);
  if(N){
   if(!N.setConfig(value))throw Error('Configuration non enregistrée.');
   cfg=next;return;
  }
  cfg=next;
  const write=configQueue.catch(()=>{}).then(async()=>store('put','config',await seal(value)));
  configQueue=write;
  try{await write;}catch(error){if(cfg===next)cfg=before;throw error;}
 }
 function checkJournalFamily(id){
  const bound=cfg.journalFamily||cfg.family?.id;
  if(bound&&bound!==id)throw Error('Cet appareil contient déjà un autre carnet partagé. Exporte-le puis efface ses données locales avant de changer de carnet.');
 }
 async function associateJournal(id){
  checkJournalFamily(id);
  if(cfg.journalFamily!==id)await setConfig({...cfg,journalFamily:id});
 }
 async function endAccountSession(family){
  try{
   const response=await fetch(endpoint(family.server,'/api/accounts/logout'),{
    method:'POST',headers:{Authorization:'Bearer '+family.token},cache:'no-store',redirect:'error',
    credentials:'omit',signal:AbortSignal.timeout(4000)
   });
   return response.ok||response.status===401;
  }catch{return false;}
 }
 async function linkFamily(family){
  checkJournalFamily(family.id);
  const previous=cfg.family,known=previous?.id===family.id&&previous.server===family.server;
  await setConfig({...cfg,family,journalFamily:family.id,accountServer:family.server,device:cfg.device||CoconModel.uid(),
   revision:0,uploaded:known?(cfg.uploaded||[]):[],lastSync:0,error:'',needsLogin:false});
  if(previous?.mode==='account'&&previous.token!==family.token)void endAccountSession(previous);
 }
 function needsLogin(family=cfg.family){
  return family?.mode==='account'&&(cfg.needsLogin||family.expiresAt*1000<=Date.now());
 }
 function reloadNativeStatus(){
  if(!N)return;
  try{
   const next=JSON.parse(N.getConfig?.()||'{}');
   if(sameFamily(next.family)&&Number(next.lastSync||0)>=Number(cfg.lastSync||0))cfg={...cfg,...next};
  }catch{}
 }
 async function setPin(oldPin,pin){
  if(N){if(!N.setPin(oldPin,pin))throw Error('Ancien code incorrect ou code invalide.');return;}
  const old=await store('get','pin');if(old){try{await open(old.box,await pinKey(oldPin,un64(old.salt)));}catch(e){throw Error('Ancien code incorrect.');}}
  if(pin){if(!/^\d{6,12}$/.test(pin))throw Error('Choisis un code de 6 à 12 chiffres.');const salt=random(16),pk=await pinKey(pin,salt);await store('put','pin',{salt:b64(salt),box:await seal(rawKey,pk)});await store('delete','deviceKey');}
  else{await store('put','deviceKey',b64(rawKey));await store('delete','pin');}hasLock=!!pin;
 }
 async function leaveFamily(){
  const previous=cfg.family;
  changingFamily=true;
  try{
   await setConfig({...cfg,family:null,journalFamily:cfg.journalFamily||previous?.id||null,
    accountServer:previous?.server||cfg.accountServer,uploaded:[],error:'',needsLogin:false,lastSync:0});
  }finally{changingFamily=false;}
  if(!N&&'serviceWorker'in navigator){
   try{
    const reg=await navigator.serviceWorker.getRegistration(),sub=await reg?.pushManager.getSubscription();
    if(sub)await sub.unsubscribe();
   }catch{}
  }
  return previous?.mode!=='account'||await endAccountSession(previous);
 }
 async function resetLocal(){
  await flush();await leaveFamily();
  if(N){
   if(!N.clearPrivateData())throw Error('Les données privées n’ont pas pu être effacées.');
  }else{
   const ids=await new Promise((resolve,reject)=>{
    const r=db.transaction('vault','readonly').objectStore('vault').getAllKeys();
    r.onsuccess=()=>resolve(r.result);r.onerror=()=>reject(r.error);
   });
   for(const id of ids)if(id!=='deviceKey'&&id!=='pin')await store('delete',id);
  }
  cfg={};raw='';
 }
 async function hasPin(){return N?!!N.hasPin():!!(await store('get','pin'));}
 async function lock(){await flush();if(N)N.lockNow();else location.reload();}
 async function putAttachment(id,data,mime){if(N){if(!N.putAttachment(id,b64(data)))throw Error('Pièce jointe non enregistrée.');}else await store('put','attachment:'+id,await seal(data));}
 async function getAttachment(id){if(N){const v=N.getAttachment(id);return v?un64(v):null;}const v=await store('get','attachment:'+id);return v?open(v):null;}
 async function importAttachment(file,babyId){if(file.size>20*1024*1024)throw Error('Maximum 20 Mo par pièce jointe.');const id=CoconModel.uid();await putAttachment(id,await file.arrayBuffer(),file.type);return {id,babyId,name:file.name.slice(0,200),mime:file.type||'application/octet-stream',size:file.size,updatedAt:Date.now()};}
 async function openAttachment(meta){let data=await getAttachment(meta.id);if(!data&&cfg.family){await syncAttachments(Cocon.state);data=await getAttachment(meta.id);}if(!data)throw Error('Ce fichier n’est pas sur cet appareil. Connecte la synchronisation ou importe une sauvegarde ZIP complète.');if(N){N.openAttachment(meta.id,meta.name,meta.mime);return;}const url=URL.createObjectURL(new Blob([data],{type:meta.mime})),a=document.createElement('a');a.href=url;a.download=meta.name;a.click();setTimeout(()=>URL.revokeObjectURL(url),30000);}
 function endpoint(base,path){const u=new URL(base);if(u.pathname!=='/'&&u.pathname!=='')throw Error('Utilise un sous-domaine dédié, sans chemin après son adresse.');if(u.protocol!=='https:'&&!(u.protocol==='http:'&&['localhost','127.0.0.1'].includes(u.hostname)))throw Error('Le serveur doit utiliser HTTPS.');if(u.username||u.password||u.search||u.hash)throw Error('Adresse serveur invalide.');return u.origin+u.pathname.replace(/\/$/,'')+path;}
 async function request(path,options={},family=cfg.family){
  if(!family)throw Error('Configure le partage entre parents.');
  const response=await fetch(endpoint(family.server,'/api/families/'+encodeURIComponent(family.id)+path),{
   ...options,headers:{'Content-Type':'application/json','Authorization':'Bearer '+family.token,...options.headers},
   credentials:'omit',redirect:'error',cache:'no-store',signal:AbortSignal.timeout(20000)
  });
  if(response.status===409)throw Object.assign(Error('conflit'),{conflict:true});
  if(!response.ok)throw exchangeError(response.status,family);
  return response.json();
 }
 function exchangeError(status,family){
  if(status===401&&family.mode==='account'){
   return Object.assign(Error('Ta session a expiré ou l’accès a été retiré. Reconnecte-toi.'),{unauthorized:true});
  }
  return Error(status===401?'Code de partage invalide ou révoqué.':'Serveur indisponible ('+status+').');
 }
 async function createFamily(server,createKey,state){
  checkJournalFamily('');
  const keyData=random(32),token=url64(random(32)),k=await aes(keyData),box=await seal(JSON.stringify(state),k);
  const response=await fetch(endpoint(server,'/api/families'),{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({token,box,createKey}),signal:AbortSignal.timeout(20000)});if(!response.ok)throw Error('Création refusée. Vérifie le serveur et son code de création.');const result=await response.json();await linkFamily({server:new URL(server).origin,id:result.id,token,key:b64(keyData)});return invitation();
 }
 function invitation(){if(!cfg.family||cfg.family.mode==='account')throw Error('Utilise une invitation pour ajouter un parent.');return 'PC2.'+url64(enc.encode(JSON.stringify(cfg.family)));}
 function parseInvitation(code){if(!code.trim().startsWith('PC2.'))throw Error('Code de partage non reconnu.');const c=JSON.parse(dec.decode(fromUrl(code.trim().slice(4))));endpoint(c.server,'');if(!/^[-a-zA-Z0-9_]{12,100}$/.test(c.id)||!/^[-a-zA-Z0-9_]{40,100}$/.test(c.token)||un64(c.key).length!==32)throw Error('Code incomplet.');return c;}
 async function joinFamily(code){const family=parseInvitation(code);checkJournalFamily(family.id);const r=await request('/state',{},family),k=await aes(un64(family.key)),state=CoconModel.validate(JSON.parse(dec.decode(await open(r.box,k))));pendingFamily=family;return state;}
 async function confirmJoin(){if(!pendingFamily)throw Error('Vérifie d’abord le code de partage.');await linkFamily(pendingFamily);pendingFamily=null;}
 const sameFamily=f=>!changingFamily&&f&&cfg.family&&cfg.family.id===f.id&&cfg.family.server===f.server&&cfg.family.token===f.token;
 async function syncAttachments(state,family=cfg.family){
  if(!family)return;
  const key=await aes(un64(family.key)),uploaded=new Set(cfg.uploaded||[]);
  for(const meta of state.attachments||[]){
   if(!sameFamily(family))return;
   const local=await getAttachment(meta.id);
   if(!sameFamily(family))return;
   const url=endpoint(family.server,'/api/families/'+family.id+'/blobs/'+encodeURIComponent(meta.id));
   const options={headers:{'Authorization':'Bearer '+family.token},redirect:'error',credentials:'omit',cache:'no-store',
    signal:AbortSignal.timeout(30000)};
   if(local){
    if(uploaded.has(meta.id))continue;
    const body=JSON.stringify(await seal(local,key));
    if(!sameFamily(family))return;
    const response=await fetch(url,{...options,method:'PUT',headers:{...options.headers,'Content-Type':'application/octet-stream'},body});
    if(!response.ok)throw exchangeError(response.status,family);
   }else{
    const response=await fetch(url,options);
    if(response.status===404)continue;
    if(!response.ok)throw exchangeError(response.status,family);
    const data=await open(await response.json(),key);
    if(!sameFamily(family))return;
    await putAttachment(meta.id,data);
   }
   uploaded.add(meta.id);
  }
  if(sameFamily(family))await setConfig({...cfg,uploaded:[...new Set([...(cfg.uploaded||[]),...uploaded])]});
 }
 async function sync(getState,apply){
  if(syncing||changingFamily||!cfg.family||needsLogin())return false;
  syncing=true;
  const family={...cfg.family};
  try{
   const key=await aes(un64(family.key));
   let revision=null;
   for(let i=0;i<5;i++){
    if(!sameFamily(family))return false;
    const remote=await request('/state',{},family);
    const other=CoconModel.validate(JSON.parse(dec.decode(await open(remote.box,key))));
    if(!sameFamily(family))return false;
    const merged=CoconCore.merge(getState(),other);
    if(CoconCore.sharedFingerprint(merged)===CoconCore.sharedFingerprint(other)){
     apply(merged);
     revision=remote.revision;
     break;
    }
    try{
     const box=await seal(JSON.stringify(merged),key);
     if(!sameFamily(family))return false;
     const result=await request('/state',{method:'PUT',body:JSON.stringify({expectedRevision:remote.revision,box})},family);
     if(!sameFamily(family))return false;
     apply(CoconCore.merge(getState(),merged));
     revision=result.revision;
     break;
    }catch(error){if(!error.conflict)throw error;}
   }
   if(revision===null)throw Error('Plusieurs modifications simultanées. Réessaie dans un instant.');
   await flush();
   await syncAttachments(getState(),family);
   if(!sameFamily(family))return false;
   await setConfig({...cfg,revision,lastSync:Date.now(),error:'',needsLogin:false});
   // A push provider or permission failure must not undo a completed journal sync.
   await registerPush(getState(),false,family).catch(()=>{});
   return true;
  }catch(error){
   if(!sameFamily(family))return false;
   const message=['TypeError','TimeoutError'].includes(error.name)?'Serveur injoignable. Les modifications restent sur cet appareil.':error.message;
   await setConfig({...cfg,error:message,needsLogin:!!error.unauthorized});
   throw Error(message);
  }finally{syncing=false;}
 }
 function scheduleAuto(getState,apply){
  clearTimeout(autoTimer);
  if(cfg.family&&!needsLogin())autoTimer=setTimeout(()=>sync(getState,apply).catch(()=>{}),1400);
 }
 async function localSnapshot(state){const day=new Date().toISOString().slice(0,10),id='snapshot:'+day;await store('put',id,await seal(JSON.stringify(state)));const ids=(await store('get','snapshotIds'))||[];if(!ids.includes(id))ids.push(id);while(ids.length>14)await store('delete',ids.shift());await store('put','snapshotIds',ids);}
 async function snapshots(){if(N)return JSON.parse(N.listSnapshots());const ids=(await store('get','snapshotIds'))||[];return ids.map(id=>({id,label:id.slice(9)})).reverse();}
 async function readSnapshot(id){return N?JSON.parse(N.readSnapshot(id)):JSON.parse(dec.decode(await open(await store('get',id))));}
 async function remoteSnapshots(){return request('/snapshots');}
 async function readRemoteSnapshot(revision){const r=await request('/snapshots/'+revision),k=await aes(un64(cfg.family.key));return CoconModel.validate(JSON.parse(dec.decode(await open(r.box,k))));}
 async function registerPush(state,ask=true,family=cfg.family){
  if(N||!sameFamily(family)||!('serviceWorker'in navigator)||!('PushManager'in window))return false;
  if(ask&&Notification.permission!=='granted')await Notification.requestPermission();if(Notification.permission!=='granted')return false;
  await navigator.serviceWorker.ready;const reg=await navigator.serviceWorker.getRegistration();if(!reg||!sameFamily(family))return false;let sub=await reg.pushManager.getSubscription();
  if(!sub&&ask){const r=await fetch(endpoint(family.server,'/api/push-key'),{redirect:'error',credentials:'omit',signal:AbortSignal.timeout(15000)});const p=await r.json();if(!p.key)throw Error('Le serveur Web Push n’est pas configuré.');sub=await reg.pushManager.subscribe({userVisibleOnly:true,applicationServerKey:fromUrl(p.key)});}
  if(!sub||!sameFamily(family))return false;const reminders=state.reminders.map(({id,at,repeat,intervalMinutes,hour,minute,weekdays,monthDay,untilAt,enabled})=>({id,at,repeat,intervalMinutes,hour,minute,weekdays,monthDay,untilAt,enabled}));
  await request('/push',{method:'POST',body:JSON.stringify({device:cfg.device,subscription:sub.toJSON(),schedule:{reminders,zone:Intl.DateTimeFormat().resolvedOptions().timeZone,quietStart:state.settings.quietStart,quietEnd:state.settings.quietEnd}})},family);return true;
 }
 // ZIP STORE writer/reader: archives contain no executable format or compression bombs.
 function crc32(a){let crc=-1;for(const b of bytes(a)){crc^=b;for(let k=0;k<8;k++)crc=(crc>>>1)^((crc&1)?0xedb88320:0);}return (crc^-1)>>>0;}
 function zipStore(entries){let offset=0;const files=[],directory=[];for(const [name,value] of entries){const data=bytes(value),n=enc.encode(name),h=new Uint8Array(30+n.length),v=new DataView(h.buffer),crc=crc32(data);v.setUint32(0,0x04034b50,true);v.setUint16(4,20,true);v.setUint16(6,0x0800,true);v.setUint32(14,crc,true);v.setUint32(18,data.length,true);v.setUint32(22,data.length,true);v.setUint16(26,n.length,true);h.set(n,30);files.push(h,data);const c=new Uint8Array(46+n.length),w=new DataView(c.buffer);w.setUint32(0,0x02014b50,true);w.setUint16(4,20,true);w.setUint16(6,20,true);w.setUint16(8,0x0800,true);w.setUint32(16,crc,true);w.setUint32(20,data.length,true);w.setUint32(24,data.length,true);w.setUint16(28,n.length,true);w.setUint32(42,offset,true);c.set(n,46);directory.push(c);offset+=h.length+data.length;}const size=directory.reduce((n,b)=>n+b.length,0),tail=new Uint8Array(22),t=new DataView(tail.buffer);t.setUint32(0,0x06054b50,true);t.setUint16(8,entries.length,true);t.setUint16(10,entries.length,true);t.setUint32(12,size,true);t.setUint32(16,offset,true);return new Blob([...files,...directory,tail],{type:'application/zip'});}
 function readZip(buffer){const a=bytes(buffer);if(a.length>128*1024*1024)throw Error('Sauvegarde supérieure à 128 Mo.');const out=new Map();let i=0;while(i+30<=a.length){const v=new DataView(a.buffer,a.byteOffset+i);if(v.getUint32(0,true)!==0x04034b50)break;const flags=v.getUint16(6,true),method=v.getUint16(8,true),size=v.getUint32(18,true),n=v.getUint16(26,true),extra=v.getUint16(28,true),start=i+30+n+extra,name=dec.decode(a.slice(i+30,i+30+n));if(method!==0||(flags&8)||size>25*1024*1024||start+size>a.length||!/^data\.json$|^attachments\/[-a-zA-Z0-9_]{1,100}$/.test(name))throw Error('Archive non compatible ou invalide.');const data=a.slice(start,start+size);if(crc32(data)!==v.getUint32(14,true))throw Error('Archive endommagée.');out.set(name,data);i=start+size;}if(!out.has('data.json'))throw Error('Ce ZIP n’est pas une sauvegarde Petit Cocon.');return out;}
 async function fullBackup(state){const entries=[['data.json',enc.encode(JSON.stringify({app:'Petit Cocon',formatVersion:2,data:state}))]];let total=entries[0][1].length;for(const meta of state.attachments||[]){const data=await getAttachment(meta.id);if(!data)throw Error('Pièce jointe absente : '+meta.name);total+=data.length;if(total>120*1024*1024)throw Error('Maximum 120 Mo par sauvegarde complète.');entries.push(['attachments/'+meta.id,data]);}return zipStore(entries);}
 async function restoreZip(buffer){const files=readZip(buffer),s=CoconModel.validate(JSON.parse(dec.decode(files.get('data.json'))));stagedFiles=files;return s;}
 async function commitImport(){if(N){if(!N.commitImportAttachments())throw Error('Pièces jointes non restaurées.');return;}if(!stagedFiles)return;for(const [path,data] of stagedFiles){if(!path.startsWith('attachments/'))continue;const id=path.slice(12);if(!(await getAttachment(id)))await putAttachment(id,data);}stagedFiles=null;}
 return {N,init,load,save,flush,resetLocal,leaveFamily,hasPin,setPin,lock,putAttachment,getAttachment,importAttachment,openAttachment,createFamily,joinFamily,confirmJoin,invitation,parseInvitation,sync,scheduleAuto,snapshots,readSnapshot,remoteSnapshots,readRemoteSnapshot,registerPush,fullBackup,restoreZip,commitImport,b64,un64,seal,open,get pendingServer(){return pendingFamily?.server||'';},get pendingId(){return pendingFamily?.id||'';},clearStaged(){stagedFiles=null;},get config(){return cfg;},setConfig,bytes,zipStore,readZip,endpoint,request,aes,random,url64,fromUrl,linkFamily,checkJournalFamily,associateJournal,needsLogin,endAccountSession,reloadNativeStatus};
})();
