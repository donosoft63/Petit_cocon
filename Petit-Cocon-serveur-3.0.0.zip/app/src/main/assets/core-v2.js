(function(root,factory){const api=factory(typeof module==='object'?require('./model.js'):root.CoconModel);if(typeof module==='object')module.exports=api;else root.CoconCore=api;})(typeof globalThis!=='undefined'?globalThis:this,function(M){
 'use strict';
 const collections=['babies','records','timers','reminders','attachments'];
 function upgrade(s){s.schema=2;s.attachments||=[];s.deleted||={};s.settings||={};s.settings.autoBackup??=true;for(const c of collections){s[c]||=[];for(const x of s[c])x.updatedAt=Number.isFinite(x.updatedAt)?x.updatedAt:(x.at||x.markAt||1);}return s;}
 const normalize=v=>Array.isArray(v)?v.map(normalize):v&&typeof v==='object'?Object.fromEntries(Object.keys(v).sort().map(k=>[k,normalize(v[k])])):v;
 function sharedFingerprint(s){const value={deleted:s.deleted||{}};for(const c of collections)value[c]=[...(s[c]||[])].sort((a,b)=>a.id.localeCompare(b.id));return JSON.stringify(normalize(value));}
 const stable=v=>JSON.stringify(v,Object.keys(v||{}).sort());
 function mark(s,previous,now=Date.now()){
  upgrade(s);const live=new Set(s.babies.map(b=>b.id));for(const c of collections.slice(1))s[c]=s[c].filter(x=>live.has(x.babyId));let old;try{old=upgrade(JSON.parse(previous));}catch(e){old={};}
  for(const c of collections){const before=new Map((old[c]||[]).map(x=>[x.id,x]));for(const x of s[c]){const a={...x},b={...(before.get(x.id)||{})};delete a.updatedAt;delete b.updatedAt;if(stable(a)!==stable(b))x.updatedAt=Math.max(now,(before.get(x.id)?.updatedAt||0)+1);before.delete(x.id);}for(const x of before.values())s.deleted[c+':'+x.id]=Math.max(now,x.updatedAt+1);}
  return s;
 }
 function merge(local,remote){
  local=upgrade(M.validate(local));remote=upgrade(M.validate(remote));const out={...local,deleted:{...local.deleted}};
  for(const [k,v] of Object.entries(remote.deleted))out.deleted[k]=Math.max(v,out.deleted[k]||0);
  for(const c of collections){const map=new Map();for(const x of [...local[c],...remote[c]]){const old=map.get(x.id);if(!old||x.updatedAt>old.updatedAt||(x.updatedAt===old.updatedAt&&stable(x)>stable(old)))map.set(x.id,x);}out[c]=[...map.values()].filter(x=>(out.deleted[c+':'+x.id]||0)<x.updatedAt);}
  if(!out.babies.length)throw Error('Cette fusion supprimerait tous les profils.');
  const ids=new Set(out.babies.map(b=>b.id));for(const c of collections.slice(1))out[c]=out[c].filter(x=>ids.has(x.babyId));
  // Concurrent timers of the same kind: deterministic winner.
  const timers=new Map();for(const t of out.timers){const key=t.babyId+':'+t.type,old=timers.get(key);if(!old||t.updatedAt>old.updatedAt||(t.updatedAt===old.updatedAt&&t.id>old.id))timers.set(key,t);}out.timers=[...timers.values()];
  if(!ids.has(out.selectedBabyId))out.selectedBabyId=out.babies[0].id;
  return M.validate(out);
 }
 function parseCsv(text){
  text=text.replace(/^\uFEFF/,'');const first=text.split(/\r?\n/)[0],sep=first.includes(';')?';':',';const rows=[];let row=[],value='',quoted=false;
  for(let i=0;i<text.length;i++){const c=text[i];if(c==='"'){if(quoted&&text[i+1]==='"'){value+='"';i++;}else quoted=!quoted;}else if(!quoted&&c===sep){row.push(value);value='';}else if(!quoted&&(c==='\n'||c==='\r')){if(c==='\r'&&text[i+1]==='\n')i++;row.push(value);if(row.some(Boolean))rows.push(row);row=[];value='';}else value+=c;}
  if(quoted)throw Error('Guillemets non fermés dans le CSV.');row.push(value);if(row.some(Boolean))rows.push(row);return rows;
 }
 function fromCsv(text,base){
  const rows=parseCsv(text);if(rows.length<2)throw Error('CSV vide.');const header=rows.shift(),col=name=>header.indexOf(name),get=(r,n)=>r[col(n)]||'';
  if(col('Date ISO')<0||col('Type')<0)throw Error('Utilise un export CSV Petit Cocon.');
  const s=upgrade(M.validate(base)),types={Tétée:'feed',Biberon:'bottle',Couche:'diaper',Sommeil:'sleep',Tirage:'pump',Repas:'meal',Croissance:'growth',Température:'temperature',Médicament:'medicine',Note:'note',Bain:'bath',Vaccin:'vaccine','Étape':'milestone',Dent:'tooth',Réaction:'allergy',Ordonnance:'prescription','Rendez-vous':'appointment','Rappel effectué':'checkin'};
  const decode=v=>v.startsWith("'")&&/^[=+@\-\t\r]/.test(v.slice(1))?v.slice(1):v;
  for(const row of rows){const name=get(row,'Bébé')||'Mon bébé',givenId=get(row,'Profil ID');let b=s.babies.find(b=>b.id===givenId)||s.babies.find(b=>b.name===decode(name));if(!b){b={id:givenId||M.uid(),name:decode(name),birthDate:'',emoji:'🌱',updatedAt:Date.now()};s.babies.push(b);}
   let r;const extra=decode(get(row,'Données JSON'));if(extra){try{r=JSON.parse(extra);}catch(e){throw Error('Colonne Données JSON invalide.');}r.babyId=b.id;}
   else {const at=Date.parse(get(row,'Date ISO'));if(!Number.isFinite(at))throw Error('Une date du CSV est invalide.');const type=types[get(row,'Type')];if(!type)throw Error('Type inconnu : '+get(row,'Type'));r={id:get(row,'Identifiant')||M.uid(),babyId:b.id,type,at,notes:decode(get(row,'Notes')),updatedAt:Date.now()};for(const [k,n,m]of [['amount','Volume (ml)',1],['weight','Poids (kg)',1],['height','Taille (cm)',1],['head','Périmètre crânien (cm)',1],['temperature','Température (°C)',1],['durationMs','Durée (min)',60000],['leftMs','Gauche (min)',60000],['rightMs','Droite (min)',60000]])if(get(row,n)!=='')r[k]=Number(get(row,n).replace(',','.'))*m;if(get(row,'Fin ISO'))r.end=Date.parse(get(row,'Fin ISO'));r.milk=get(row,'Lait');r.diaper=({Urine:'wet',Selles:'dirty','Urine et selles':'both','Sèche':'dry'})[get(row,'Couche')];r.medicine=decode(get(row,'Médicament'));r.dose=decode(get(row,'Dose notée'));r.food=decode(get(row,'Aliment'));}
   const identical=s.records.find(x=>x.id===r.id||(x.babyId===r.babyId&&x.type===r.type&&x.at===r.at&&x.notes===(r.notes||'')&&x.amount===r.amount));if(identical){if(r.updatedAt>identical.updatedAt)Object.assign(identical,r);}else s.records.push(r);
  }return M.validate(s);
 }
 function dose(p){
  const mg=Number(p.doseMg),conc=Number(p.concentration);if(!Number.isFinite(mg)||mg<=0||!Number.isFinite(conc)||conc<=0)throw Error('Renseigne la dose prescrite en mg et la concentration en mg/ml.');
  const ml=mg/conc;if(!Number.isFinite(ml)||ml<=0)throw Error('Conversion impossible.');return {mg,ml};
 }
 function monthDate(birth,months){const d=new Date(birth+'T09:00:00');const wanted=d.getDate();d.setDate(1);d.setMonth(d.getMonth()+months);const end=new Date(d.getFullYear(),d.getMonth()+1,0).getDate();d.setDate(Math.min(wanted,end));return +d;}
 const vaccineSchedule=[['hexa',1,2,'DTP, coqueluche, Hib, hépatite B'],['pneumo',1,2,'Pneumocoque'],['menb',1,3,'Méningocoque B'],['hexa',2,4,'DTP, coqueluche, Hib, hépatite B'],['pneumo',2,4,'Pneumocoque'],['menb',2,5,'Méningocoque B'],['menacwy',1,6,'Méningocoques ACWY'],['hexa',3,11,'DTP, coqueluche, Hib, hépatite B'],['pneumo',3,11,'Pneumocoque'],['menb',3,12,'Méningocoque B'],['menacwy',2,12,'Méningocoques ACWY'],['ror',1,12,'Rougeole, oreillons, rubéole'],['ror',2,16,'Rougeole, oreillons, rubéole (fenêtre 16–18 mois)']];
 function vaccines(b,records){if(!b.birthDate)return [];return vaccineSchedule.map(([code,doseIndex,ageMonths,label])=>({id:code+'-'+doseIndex,code,doseIndex,ageMonths,label,dueAt:monthDate(b.birthDate,ageMonths),done:records.find(r=>r.babyId===b.id&&r.type==='vaccine'&&r.vaccineCode===code&&r.doseIndex===doseIndex)}));}
 function nextReminder(r,now=Date.now()){const due=nextTime(r,now);return r.untilAt&&due>r.untilAt?null:due;}
 function nextTime(r,now=Date.now()){
  if(!r.enabled)return null;if(r.at>now&&r.repeat!=='weekly')return r.at;if(r.repeat==='once')return null;if(r.repeat==='interval'){const step=Math.max(1,r.intervalMinutes)*60000;return r.at+(Math.floor((now-r.at)/step)+1)*step;}
  const base=new Date(r.at),d=new Date(Math.max(now,r.at));d.setHours(r.hour??base.getHours(),r.minute??base.getMinutes(),0,0);
  if(r.repeat==='monthly'){const day=r.monthDay||base.getDate();for(let i=0;i<25;i++){const month=new Date(d.getFullYear(),d.getMonth()+i,1,d.getHours(),d.getMinutes());month.setDate(Math.min(day,new Date(month.getFullYear(),month.getMonth()+1,0).getDate()));if(+month>now&&+month>=r.at)return +month;}return null;}
  for(let i=0;i<9;i++){if(+d>now&&+d>=r.at&&(r.repeat!=='weekly'||(r.weekdays?.length?r.weekdays:[base.getDay()]).includes(d.getDay())))return +d;d.setDate(d.getDate()+1);}return null;
 }
 function cdf(z){const t=1/(1+.2316419*Math.abs(z)),p=.3989422804*Math.exp(-z*z/2)*t*(.319381530+t*(-.356563782+t*(1.781477937+t*(-1.821255978+t*1.330274429))));return z>=0?1-p:p;}
 function lmsAt(table,days){if(!table?.length||days<0||days>=table.length)return null;const lo=Math.floor(days),hi=Math.min(table.length-1,lo+1),a=days-lo;return table[lo].map((v,i)=>v+(table[hi][i]-v)*a);}
 function growthLms(data,metric,sex,days){return lmsAt(data?.[metric]?.[sex],days);}
 function percentile(data,metric,b,at,value){if(!b.birthDate||!b.sex||value<=0)return null;const utcDay=t=>{const d=new Date(t);return Date.UTC(d.getFullYear(),d.getMonth(),d.getDate());},days=(utcDay(at)-utcDay(new Date(b.birthDate+'T12:00:00')))/86400000,lms=growthLms(data,metric,b.sex,days);if(!lms)return null;const [L,median,S]=lms,z=L===0?Math.log(value/median)/S:(Math.pow(value/median,L)-1)/(L*S);return {z,percentile:cdf(z)*100,days};}
 function referenceValue(data,metric,sex,days,z){const p=growthLms(data,metric,sex,days);if(!p)return null;const [L,median,S]=p;return L===0?median*Math.exp(S*z):median*Math.pow(1+L*S*z,1/L);}
 return {collections,upgrade,mark,merge,sharedFingerprint,parseCsv,fromCsv,dose,monthDate,vaccines,vaccineSchedule,nextReminder,percentile,referenceValue};
});
