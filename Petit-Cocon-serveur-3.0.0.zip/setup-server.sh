#!/usr/bin/env bash
set -euo pipefail
project_root="$(cd "$(dirname "$0")" && pwd)"
cd "$project_root"
cocon_domain="${1:-}"
cocon_mode="${2:-host}"
if [[ -z "$cocon_domain" ]] || [[ "$cocon_mode" != "host" && "$cocon_mode" != "proxy" ]]; then
  echo 'Utilisation : bash setup-server.sh cocon.example.fr [host|proxy]'
  exit 1
fi
docker compose version >/dev/null
umask 077
python3 - "$cocon_domain" <<'PY'
from pathlib import Path
import sys,re,secrets
domain=sys.argv[1].lower()
if len(domain)>253 or not re.fullmatch(r'[a-z0-9](?:[a-z0-9.-]*[a-z0-9])?\.[a-z]{2,63}',domain):
    raise SystemExit('Indique un nom de domaine, sans https:// ni chemin.')
p=Path('.env')
if p.exists():
    old=dict(line.split('=',1) for line in p.read_text().splitlines() if '='in line and not line.startswith('#'))
    if old.get('COCON_DOMAIN')!=domain:raise SystemExit('Le domaine de .env est différent. Le fichier a été conservé ; corrige-le manuellement si nécessaire.')
    print('Configuration existante conservée.')
else:
    with p.open('x') as settings:
        settings.write('COCON_DOMAIN='+domain+'\nCOCON_CREATE_KEY='+secrets.token_urlsafe(36)+'\nCOCON_PROXY_NETWORK=proxy\n')
    print('Configuration créée. Le code de création se trouve dans .env.')
PY
compose=(docker compose -f compose.yaml)
if [[ "$cocon_mode" == "proxy" ]]; then
  compose+=(-f compose.caddy.yaml)
fi
"${compose[@]}" up -d --build --wait --wait-timeout 90
echo 'Serveur Petit Cocon démarré. Termine la configuration HTTPS de Caddy et ouvre ton sous-domaine.'
