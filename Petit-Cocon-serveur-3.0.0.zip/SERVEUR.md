# Petit Cocon 3.0.0 sur Debian

Le paquet contient le serveur de comptes, l’API de synchronisation et l’application web. Le service peut être utilisé sur Android, dans Safari sur iPhone et depuis un navigateur sur ordinateur.

## Installation

Il te faut Docker avec le plugin Docker Compose, Python 3 pour le script d’installation et un sous-domaine HTTPS qui pointe vers le serveur Debian. Décompresse `Petit-Cocon-serveur-3.0.0.zip` dans un dossier du serveur. Remplace `cocon.example.fr` par ton sous-domaine dans les commandes et dans Caddy.

**Caddy dans Docker.** Dans le dossier décompressé, lance :

```bash
bash setup-server.sh cocon.example.fr proxy
```

Caddy et Petit Cocon doivent être sur le même réseau Docker. Le nom par défaut est `proxy`. Si ton réseau porte un autre nom, crée ou modifie `.env` avec `COCON_PROXY_NETWORK`, puis relance le script.

```caddyfile
cocon.example.fr {
    reverse_proxy petit-cocon:8080
}
```

**Caddy installé sur Debian.** Lance le script en mode `host`, puis ajoute le bloc suivant à la configuration de Caddy.

```bash
bash setup-server.sh cocon.example.fr host
```

```caddyfile
cocon.example.fr {
    reverse_proxy 127.0.0.1:8097
}
```

Recharge ton reverse proxy et vérifie l’adresse publique avec une requête HTTPS.

```bash
curl -fsS https://cocon.example.fr/api/health
```

La réponse contient `"version":3` et `"accounts":true`. La page d’accueil est accessible à la même adresse, sans `/api/health`. Les exemples Caddy complets sont inclus dans l’archive. Le backend écoute sur `127.0.0.1:8097` côté Debian. En mode `proxy`, il est aussi joignable par Caddy sur le réseau Docker interne.

## Créer le premier compte

1. Sur Android, installe l’APK 3.0.0 par-dessus la version existante. Sur iPhone ou ordinateur, ouvre l’adresse HTTPS du serveur.
2. Ouvre **Plus → Entre parents → Créer le premier compte**. Utilise l’appareil qui contient ton carnet si tu veux partager ses données actuelles.
3. Saisis ton adresse e-mail, un mot de passe et la valeur de `COCON_CREATE_KEY` dans le fichier `.env` du serveur. Le script crée ce code au premier lancement.
4. Choisis **Inviter un parent**. Transmets le code `PC3.` à la personne invitée. Elle choisit **Rejoindre avec une invitation** et crée son propre compte. L’inscription consomme le code, qui expire au bout de 48 heures.
5. Sur un appareil supplémentaire, choisissez **Se connecter** avec le compte existant. Le mot de passe permet à l’appareil de déchiffrer la clé du carnet. Sur Wear OS, utilise le bouton **Connexion avec un compte**.

L’inscription est privée. Elle demande le code de création du serveur pour le premier compte, puis une invitation par parent. Le propriétaire peut retirer un parent ou annuler une invitation dans **Accès au carnet**. Les appareils d’un parent retiré ne peuvent plus lire ou envoyer de données au serveur. Ils conservent leur copie locale.

La session est propre à chaque connexion et expire après 30 jours. Le changement de mot de passe depuis **Entre parents** ferme les autres sessions de ce compte. Le mot de passe peut être modifié en renseignant le mot de passe actuel. Une copie du volume serveur seule ne permet pas de récupérer le carnet si les mots de passe de tous les membres ont été perdus. Un ZIP complet exporté depuis un appareil permet une restauration indépendante.

## Faire évoluer un serveur V2

1. Dans ton dossier d’installation, conserve `.env`, le même projet Docker Compose et son volume `cocon-data`. Fais une copie du volume et de `.env` avant la mise à jour. Exporte également un ZIP depuis un appareil qui contient le carnet.
2. Décompresse les fichiers V3 dans le dossier d’installation, puis relance `setup-server.sh` avec le domaine et le mode utilisés en V2. La base SQLite est mise à jour au démarrage.
3. Installe la V3 sur le téléphone qui a accès au carnet. Dans **Plus → Entre parents**, choisis **Activer les comptes sur ce carnet**. Saisis le code de création du serveur et les identifiants du propriétaire.
4. Invite les autres parents. Connecte les appareils supplémentaires avec leurs comptes. Les anciens codes `PC2.` du carnet migré cessent de fonctionner.

La migration garde le carnet chiffré, ses fichiers et son historique dans le même volume. Elle retire les anciennes autorisations de partage. Si la réponse de migration a été interrompue et que le carnet a déjà basculé, utilise **Se connecter** avec les identifiants saisis lors de l’activation.

## Synchronisation et stockage

Les saisies fonctionnent hors ligne. La synchronisation se lance après une modification, au retour de la connexion et toutes les 30 secondes lorsque l’interface est visible. Android peut aussi échanger en arrière-plan lorsque le système le permet. Les entrées distinctes sont fusionnées. En cas de modification simultanée de la même entrée, le dernier horodatage l’emporte. Les suppressions sont propagées.

Le volume conserve la base des comptes, les carnets et pièces jointes chiffrés, jusqu’à 50 versions précédentes par carnet et la configuration Web Push. La clé du carnet est stockée chiffrée pour chaque compte. Les e-mails, les prénoms et les métadonnées nécessaires aux rappels push sont traités par le serveur. La sauvegarde du volume doit inclure la base SQLite et les pièces jointes. Pour une copie cohérente de l’ensemble, arrête le service pendant la sauvegarde du volume.

Conserve le volume lorsque tu reconstruis le conteneur. La commande `docker compose down -v` supprime ses données. Une sauvegarde ZIP de l’application contient le journal et ses fichiers en clair. Range-la dans un emplacement privé.

Sur iPhone, ajoute l’application à l’écran d’accueil depuis Safari. L’option **Plus → Autres appareils → Activer les notifications web** permet d’activer Web Push sur les appareils compatibles. Le serveur envoie un texte générique. Les alarmes Android de l’APK restent locales.

## Références

- [Docker Engine sur Debian](https://docs.docker.com/engine/install/debian/)
- [Plugin Docker Compose](https://docs.docker.com/compose/install/linux/)
- [Reverse proxy Caddy](https://caddyserver.com/docs/caddyfile/directives/reverse_proxy)
